<style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #0000FF;
	font-size: 14px;
}
.style4 {font-size: 14px}
-->
</style>
<marquee>
Selamat datang di e-Learning MTSS PUI Maja - Jawa Barat. Silahkan <b>Registrasi</b> untuk mendapatkan akun siswa, silahkan <b>Login</b> untuk masuk ke dalam sistem.</marquee><br>
<br>
<hr>

<br>
<h1 align="justify"><img src='images/logo.png' width='25' height='25'></img>&nbsp;&nbsp;&nbsp;<b>Kata Sambutan</b></h1>
<p style="text-align: justify;"><b>Assalamualaikum Wr.Wb.</b></p>
<p style="text-align: justify;">Puji syukur ke hadirat Allah SWT dan sholawat kepada baginda Rasulullah SAW,</p>
<p style="text-align: justify;">Salam sejahtera bagi kita semua, dengan adanya Website official MTSS PUI Maja - Jawa Barat, kami berharap info-info terkini tentang madrasah kita ini dapat terus diberitakan. Kami turut bangga dengan prestasi-prestasi yang diukir oleh para siswa beserta para guru pembimbing mereka.</p>
<p style="text-align: justify;">Kepada masyarakat yang telah mempercayakan anak-anaknya di madrasah yang kami pimpin, kiranya marilah kita tebarkan kebajikan sebanyaknya dan seluas-luasnya. Mohon dukungan untuk peningkatan mutu dan prestasi madrasah kita baik moral maupun spiritual dan tak kalah pentingnya material yang telah disumbangkan dan kini menjadi amal jariyah bagi kita semua.</p>
<p style="text-align: justify;">Semoga, ke depannya MTSS PUI Maja - Jawa Barat tetap menjadi yang terbaik di tingkat nasional dan internasional nantinya. Para alumni juga kami mintakan untuk turut serta membangun dan menggugah adik-adiknya agar bisa sukses sebagaimana abang-kakaknya yang telah melampaui pendidikan di madrasah terbesar di Jawa Barat ini.</p>
<p style="text-align: justify;">Akhir kata,<br />Sebagai pimpinan MTSS PUI Maja - Jawa Barat, kami mengucapkan ribuan terimakasih yang sebesar-besarnya, semoga saluran informasi resmi ini mampu memberikan informasi terbaik bagi kita semua. aamiin</p>
<p style="text-align: justify;"><em>Wassalam Wr Wb</em></p>
<p style="text-align: justify;"><strong>Kepala Sekolah</strong></p> 