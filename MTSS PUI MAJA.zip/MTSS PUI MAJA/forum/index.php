<?php
   include '../configurasi/koneksi.php'; //hubungkan dengan database

   session_start();
   if(!isset($_SESSION['username'])){
      header("location:../index.php");
      exit();
   }

   if(isset($_SESSION['username'])){
      $username = $_SESSION['username'];
   }

   $query=mysql_fetch_array(mysql_query("select * from forum_login where username='$username'"));
   $query2=mysql_fetch_array(mysql_query("select * from forum_topik where pengirim='$username'"));

   //Menghitung jumlah topik dan jumlah member
   $query3 = mysql_query("SELECT * FROM forum_topik");
   $query4 = mysql_query("SELECT * FROM forum_login");
   $jumlah_topik = mysql_num_rows($query3);
   $jumlah_member = mysql_num_rows($query4);
   //mencari total view (dilihat)

   if(isset($_GET['id_topik'])){
      $id_topik = $_GET['id_topik'];
   }else{
      $id_topik = "";
   }

   $query6=mysql_fetch_array(mysql_query("select dilihat from forum_topik where id_topik='$id_topik'"));
   $dilihat = $query6 ['dilihat'] + 1;
   $sql2 = "UPDATE forum_topik SET dilihat='$dilihat' WHERE id_topik='$id_topik'";
   $hasil2 = mysql_query($sql2);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <title>Forum Diskusi Member</title>
</head>

<body>
   <div align="center">
      <font size="6" class="merah"><br><br>Forum Diskusi<br><br></font><br />
      <table width="700" border="0" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px;">
         <tr>
            <td height="29"> <div align="right"><strong class="hijau">Anda Login Sebagai : <?php echo $_SESSION['username']; echo "  "?> </strong></div></td>
         </tr>
         <tr>
            <td> </td>
         </tr>
         <tr>
            <?php
               if(isset($_GET['id_topik'])){
                  $id_topik = $_GET['id_topik'];
               }else{
                  $id_topik = "";
               }

               $query5=mysql_fetch_array(mysql_query("select * from forum_topik where id_topik='$id_topik'"));
            ?>

            <td height="86">
               <div align="center">
                  <div align="center" style="overflow:auto; width:790px; height:200px;">
                     <table width="771" border="0">
                        <tr>
                           <td width="62" bgcolor="#CCCCCC"><div align="center">#</div></td>
                           <td width="253" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Topik</font></div></td>
                           <td width="128" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Pengirim</font></div></td>
                           <td width="59" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Balasan</font></div></td>
                           <td width="60" bgcolor="#CCCCCC"><div align="center">Dilihat</div></td>
                           <td width="183" bgcolor="#CCCCCC"><div align="center"><font face="verdana" size="2">Tanggal</font></div></td>
                        </tr>

                        <?php
                           $nomor = 1;

                           $sql = "SELECT * FROM forum_topik ORDER by tanggal DESC";
                           $hasil=mysql_query($sql);
                           while($record=mysql_fetch_array($hasil)){
                        ?>

                        <tr>
                           <td valign="top"> <font face="verdana" size="2"><?php echo $nomor++; ?></font></td>
                           <td valign="top"><font face="verdana" size="2"><a href="view.php?id_topik=<?php echo $record['id_topik']; ?>"><?php echo $record['topik']; ?></a></font></td>
                           <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['pengirim']; ?></font></div></td>
                           <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['total_balasan']; ?></font></div></td>
                           <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['dilihat']; ?></font></div></td>
                           <td valign="top"><div align="center"><font face="verdana" size="2"><?php echo $record['tanggal']; ?></font></div></td>
                        </tr>

                        <?php
                           //Berhenti Looping
                           }
                           mysql_close();
                        ?>
                     </table>
                  </div>
               </div>
            </td>
         </tr>
         <tr>
            <td><div align="right"></div></td>
         </tr>
         <tr>
            <td width="735">
            <div align="center">
               <table width="694" height="28" border="0">
                  <tr>
                     <td width="108"><div align="center"><strong><a href="create.php"><img src="image/new.png" width="64" height="64" title="Buat Thread Baru" /></a><br />Thread Baru</strong></div></td>
                     <td width="108"><div align="center"><strong><a href="logout.php"><img src="image/logout.jpg" width="64" height="64" title="Kembali ke Halaman Website" /></a><br />Halaman Website</strong></div></td>
                  </tr>
               </table>
            </div>
            </td>
         </tr>
         <tr>
            <td bgcolor="#000000">
               <div align="center">
                  <table width="395" border="0">
                     <tr class="hijau">
                        <td><div align="center" class="hijau"><strong>Total Thread : <?php echo $jumlah_topik ?></strong></div></td>
                        <td><div align="center" class="hijau"><strong>Total Member : <?php echo $jumlah_member ?></strong> </div></td>
                     </tr>
                  </table>
               </div>
            </tr>
             </td>
         </table>
      </div>
</body>
</html>