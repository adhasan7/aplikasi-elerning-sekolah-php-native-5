<?php
   $pengirim = $_POST['username'];
   $topik = $_POST['topik'];
   $isi = $_POST['isi'];

   $tanggal = date("Y-m-d H:i:s");

   include '../configurasi/koneksi.php'; //hubungkan dengan database

   if (empty($isi) || empty($topik))
   {
      header("location:create.php?status=Maaf, semua field harus di isi.");
   }
   else{
      $sql = "INSERT INTO forum_topik (pengirim, topik, isi, tanggal) VALUES ('$pengirim', '$topik', '$isi', '$tanggal')";
      $hasil = mysql_query($sql);

      if($hasil){
         echo "<script> alert('Thread berhasil ditambahkan'); location = 'index.php'; </script>";
      }
      else {
          echo "<script> alert('Thread gagal ditambahkan'); location = 'create.php'; </script>";
      }
   }
?>