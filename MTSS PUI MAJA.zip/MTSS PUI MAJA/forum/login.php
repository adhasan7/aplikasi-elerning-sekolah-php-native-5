<?php
   session_start();  

   if(isset($_SESSION['namauser'])){
      $_SESSION['username']=$_SESSION['namauser'];  
      header("location:index.php"); // dan alihkan ke halaman forum
   }else{ //jika belum login
      echo "<script> alert('Silahkan login terlebih dahulu...!'); location = '../index.php'; </script>";
   }
?>