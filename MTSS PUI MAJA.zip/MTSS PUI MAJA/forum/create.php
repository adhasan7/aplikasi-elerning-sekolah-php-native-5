<?php
   session_start();
   if(!isset($_SESSION['username'])){
      header("location:../index.php");
      exit();
   }

   if(isset($_SESSION['username'])){
      $username = $_SESSION['username'];
   }
   include '../configurasi/koneksi.php'; //hubungkan dengan database
   $query=mysql_fetch_array(mysql_query("select * from forum_login where username='$username'"));
   $query2=mysql_fetch_array(mysql_query("select * from forum_topik where pengirim='$username'"));

   //Menghitung jumlah topik dan jumlah member
   $query3 = mysql_query("SELECT * FROM forum_topik");
   $query4 = mysql_query("SELECT * FROM forum_login");
   $jumlah_topik = mysql_num_rows($query3);
   $jumlah_member = mysql_num_rows($query4);
   //mencari total view (dilihat)

   if(isset($_GET['id_topik'])){
      $id_topik = $_GET['id_topik'];
   }else{
      $id_topik = "";
   }

   $query6=mysql_fetch_array(mysql_query("select dilihat from forum_topik where id_topik='$id_topik'"));
   $dilihat = $query6 ['dilihat'] + 1;
   $sql2 = "UPDATE forum_topik SET dilihat='$dilihat' WHERE id_topik='$id_topik'";
   $hasil2 = mysql_query($sql2);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <title>Thread Baru</title>
</head>

<body>
   <div align="center">
   <font size="6" class="merah"><br><br>Forum Diskusi<br><br></font><br />
      <table width="700" border="0" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px;">
         <tr>
            <td height="29" bgcolor="#000000"> <div align="right"><strong class="hijau">Anda Login Sebagai : <?php echo $_SESSION['username']; echo "  "?> </strong></div></td>
         </tr>
         <tr>
            <td> </td>
         </tr>
         <tr>
            <?php
               if(isset($_GET['id_topik'])){
                  $id_topik = $_GET['id_topik'];
               }else{
                  $id_topik = "";
               }

               $query5=mysql_fetch_array(mysql_query("select * from forum_topik where id_topik='$id_topik'"));
            ?>

            <td height="86">
               <div align="center">
                  <div align="center">
                     <form id="form1" name="form1" method="post" action="proses_create.php">
                        <table width="443" border="0">
                           <tr>
                              <td colspan="3" bgcolor="#CCCCCC"><div align="center"><strong><font face="verdana" size="5">Thread Baru</font></strong></div></td>
                           </tr>
                           <tr>
                              <td colspan="3" valign="top">
                                 <div align="center" class="merah1"> <strong>
                                    <?php
                                       if(isset($_GET['status'])){
                                          $status = $_GET['status'];
                                       }
                                       else{
                                          $status = "";
                                       }

                                        echo "$status";
                                     ?>
                                  </strong></div>
                               </td>
                            </tr>
                            <tr>
                               <td valign="top"><strong>Username</strong></td>
                               <td valign="top"><div align="center"><strong>:</strong></div></td>
                               <td valign="top"><input name="username" type="text" id="username" value="<?php echo $username?>" readonly="readonly" /></td>
                            </tr>
                            <tr>
                               <td width="131" valign="top"><strong>Topik</strong></td>
                               <td width="13" valign="top"><div align="center"><strong>:</strong></div></td>
                               <td width="285" valign="top"><strong>
                                  <input name="topik" type="text" maxlength="40" />* ( Judul Thread )</strong></td>
                            </tr>
                            <tr>
                               <td valign="top"><strong>Isi</strong></td>
                               <td valign="top"><div align="center"><strong>:</strong></div></td>
                               <td valign="top"><strong>
                                  <textarea name="isi" cols="45" rows="5"></textarea>
                                  </strong>
                               </td>
                            </tr>
                            <tr>
                               <td valign="top"> </td>
                               <td valign="top"> </td>
                               <td valign="top"><input type="submit" value="Kirim" /> 
                                  <input type="reset" value="Hapus" /></td>
                            </tr>
                            <tr>
                               <td colspan="3" valign="top" bgcolor="#CCCCCC"><div align="center"></div></td>
                            </tr>
                         </table>
                      </form>
                   </div>
                </div>
             </td>
          </tr>
          <tr>
             <td><div align="right"></div></td>
          </tr>
          <tr>
             <td bgcolor="#000000">
                <div align="center">
                   <table width="395" border="0">
                      <tr class="hijau">
                         <td><div align="center" class="hijau"><strong>Total Thread : <?php echo $jumlah_topik ?></strong></div></td>
                         <td><div align="center" class="hijau"><strong>Total Member : <?php echo $jumlah_member ?></strong> </div></td>
                      </tr>
                   </table>
                </div>
             </td>
          </tr>
       </table>
   </div>
</body>
</html>

