<?php
   $id_topik = $_POST['id_topik'];
   $topik = $_POST['topik'];
   $penjawab = $_POST['penjawab'];
   $isi = $_POST['isi'];

   $tanggal = date("Y-m-d H:i:s");

   include '../configurasi/koneksi.php'; //hubungkan dengan database
   if (empty($isi))
   {
      header("location:balas.php?id_topik=$id_topik&status=Maaf, field komentar tidak boleh kosong");
   }
   else{
      $sql = "INSERT INTO forum_komentar (id_topik, topik, penjawab, isi, tanggal) VALUES ('$id_topik', '$topik', '$penjawab', '$isi', '$tanggal')";
      $hasil = mysql_query($sql);
      if($hasil){
         echo "<script> location = 'view.php?id_topik=$id_topik'; </script>";
      }
      else {
         echo "<script> alert('Komentar gagal ditambahkan'); location = 'forum.php'; </script>";
      }

      $query_balasan = mysql_query("SELECT id_topik FROM forum_komentar WHERE id_topik='$id_topik'");
      $total_balas = mysql_num_rows($query_balasan);
      $total_balasan = $total_balas;

      //memasukan total balasan ke database
      $sql2 = "UPDATE forum_topik SET total_balasan='$total_balasan' WHERE id_topik='$id_topik'";
      $hasil2 = mysql_query($sql2);

      if($hasil2){
         echo "ok";
      }
      else {
         echo "<script> alert('Komentar gagal ditambahkan'); location = 'forum.php'; </script>";
      }
   }
?>