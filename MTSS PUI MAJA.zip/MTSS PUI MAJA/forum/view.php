<?php
   session_start();
   if(!isset($_SESSION['username'])){
      header("location:../index.php");
      exit();
   }

   if(isset($_SESSION['username'])){
      $username = $_SESSION['username'];
   }
   
   include '../configurasi/koneksi.php'; //hubungkan dengan database
   $query=mysql_fetch_array(mysql_query("select * from forum_login where username='$username'"));
   $query2=mysql_fetch_array(mysql_query("select * from forum_topik where pengirim='$username'"));

   //Menghitung jumlah topik dan jumlah member
   $query3 = mysql_query("SELECT * FROM forum_topik");
   $query4 = mysql_query("SELECT * FROM forum_login");
   $jumlah_topik = mysql_num_rows($query3);
   $jumlah_member = mysql_num_rows($query4);
   //mencari total view (dilihat)

   if(isset($_GET['id_topik'])){
      $id_topik = $_GET['id_topik'];
   }else{
      $id_topik = "";
   }

   $query6=mysql_fetch_array(mysql_query("select dilihat from forum_topik where id_topik='$id_topik'"));
   $dilihat = $query6 ['dilihat'] + 1;
   $sql2 = "UPDATE forum_topik SET dilihat='$dilihat' WHERE id_topik='$id_topik'";
   $hasil2 = mysql_query($sql2);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <title>View
      <?php
         //Mengambil judul topik
         $query6=mysql_fetch_array(mysql_query("select * from forum_topik where id_topik='$id_topik'"));
         echo "" .$query6['topik']. ""
      ?>
   </title>
</head>

<body>
   <div align="center">
      <p><font size="6" class="merah"><br><br>Forum Diskusi<br><br></font></p>
      <table width="700" border="0" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px;">
         <tr>
            <td height="29"> <div align="right"><strong class="hijau">Anda Login Sebagai : <?php echo $_SESSION['username']; echo "  "?> </strong></div></td>
         </tr>
         <tr>
            <td> </td>
         </tr>
         <tr>
            <?php
               if(isset($_GET['id_topik'])){
                  $id_topik = $_GET['id_topik'];
               }else{
                  $id_topik = "";
               }

               $query5=mysql_fetch_array(mysql_query("select * from forum_topik where id_topik='$id_topik'"));

               //mencari gambar pengirim thread
               $username = $query5['pengirim'];
               $query7=mysql_fetch_array(mysql_query("select * from forum_login where username='$username' "));
            ?>

            <td height="304">
               <table width="100%" border="1" cellpadding="3" cellspacing="1" bordercolor="1" bgcolor="#FFFFFF" style="border: 2px solid gray; border-radius: 10px 10px 10px 10px; background:#fff;">
                  <tr>
                     <td width="100%" bgcolor="#CCCCCC"><strong><img src="image/thread.png" alt="" width="22" height="22" align="left" />Dikirim <?php echo $query5['tanggal']; ?></strong></td>
                     <td width="100%" height="27" bgcolor="#CCCCCC"><div align="right"><strong># 1</strong></div></td>
                  </tr>
                  <tr>
                     <td colspan="2" valign="top" ><p><strong>
                        <span class="merah"><font size="3">Topik :</font><font size="3"></font></span><font size="3"> <?php echo $query5['topik']; ?><br />
                        </font></strong>
                        <strong><font size="3"><hr /></font></strong></p>
                        <pre><?php echo $query5['isi']; ?></pre>
                     </td>
                  </tr>
                  <tr>
                     <td colspan="2" valign="top" bgcolor="#CCCCCC">
                        <div align="right">
                           <table width="293" border="0">
                              <tr>
                                 <td width="133"><div align="right"><strong><?php echo $query5['total_balasan']; ?> balasan </strong></div></td>
                                 <td width="252"><div align="right"><strong><?php echo $query5['dilihat']; ?> kali dilihat</strong></div></td>
                              </tr>
                           </table>
                        </div>
                     </td>
                  </tr>
               </table>

               <div align="right"><a href="balas.php?id_topik=<?php echo $id_topik; ?>"><img src="image/reply.gif" width="72" height="26" title="Balas Thread Ini" /></a><br />
               </div>
               <div align="right"></div>
               <div align="left"><strong>Respon untuk "<?php echo $query5['topik']; ?>"</strong>
                  <br />
               </div>
               <p>
                  <?php
                     // Menampilkan komentar
                     $nomor = 2;
                     $sql2="SELECT * FROM forum_komentar WHERE id_topik='$id_topik' ORDER BY tanggal DESC";
                     $result2=mysql_query($sql2);
                     while($rows=mysql_fetch_array($result2)){
                  ?>
               </p>
               <table width="100%" border="0">
            <tr>
               <td bgcolor="#CCCCCC">
                  <table width="100%" border="0">
                     <tr>
                        <td width="27%" valign="top">Tanggal : <?php echo $rows['tanggal']; ?></td>
                        <td width="27%" valign="top"> </td>
                        <td width="27%" valign="top"><div align="right"><strong># <?php echo $nomor++; ?></strong></div></td>
                     </tr>
                     <tr>
                        <td height="20" colspan="3" valign="top">
                           <p>
                              <?php
                                 //Menyesuaikan gambar / avatar
                                 $user2 = $rows['penjawab'];
                                 $queryAvatar=mysql_fetch_array(mysql_query("select * from forum_login where username='$user2'"));
                              ?>

                              <?php echo $rows['penjawab']; ?><br />
                              <strong>    <em>Re : <?php echo $rows['topik']; ?></em></strong><br />
                           </p>
                           <hr />
                           <pre><?php echo $rows['isi']; ?></pre>
                        </td>
                     </tr>
                     <tr>
                        <td height="18" colspan="3" valign="top" bgcolor="#CCCCCC"> </td>
                     </tr>
                  </table>
               </td>
            </tr>
         </table>
         <p>
            <?php
               }
            ?>
         </p>
         </td>
      </tr>
      <tr>
         <td><div align="right"><a href="forum.php"><img src="image/back.jpg" alt="" width="72" height="26" title="Kembali ke Thread Ini"/></a></div></td>
      </tr>      
      <tr>
         <td bgcolor="#000000">
            <div align="center">
               <table width="395" border="0">
                  <tr class="hijau">
                     <td><div align="center" class="hijau"><font color="green"><strong>Total Thread : <?php echo $jumlah_topik ?></strong></font> </div></td>
                     <td><div align="center" class="hijau"><font color="green"><strong>Total Member : <?php echo $jumlah_member ?></strong></font> </div></td>
                  </tr>
               </table>
            </div>
         </td>
      </tr>
   </table>
</div>
</body>
</html>