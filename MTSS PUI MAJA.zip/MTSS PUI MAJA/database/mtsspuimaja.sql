-- phpMyAdmin SQL Dump
-- version 3.4.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 05, 2020 at 03:00 PM
-- Server version: 5.1.73
-- PHP Version: 5.3.3-7+squeeze26

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mtsspuimaja`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE IF NOT EXISTS `absensi` (
  `ip` varchar(20) NOT NULL,
  `id_siswa` int(50) NOT NULL,
  `tanggal` datetime NOT NULL,
  `online` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`ip`, `id_siswa`, `tanggal`, `online`) VALUES
('116.206.15.8', 1, '2020-03-31 00:00:00', 'T'),
('114.125.15.179', 1, '2020-04-06 22:37:07', 'T'),
('114.5.210.228', 1, '2020-04-13 16:50:28', 'T'),
('114.125.15.124', 1, '2020-04-13 20:33:49', 'T'),
('114.125.31.141', 1, '2020-04-13 20:36:06', 'T'),
('114.5.253.43', 1, '2020-04-13 20:54:41', 'T'),
('114.5.253.43', 1, '2020-04-13 21:29:52', 'T'),
('114.125.15.124', 1, '2020-04-13 21:35:40', 'T'),
('120.188.38.57', 1, '2020-04-18 23:01:57', 'T'),
('120.188.38.57', 1, '2020-04-18 23:25:11', 'Y'),
('114.5.253.92', 1, '2020-04-19 21:27:56', 'Y'),
('114.122.6.149', 2, '2020-04-19 22:03:17', 'Y'),
('114.5.248.83', 1, '2020-04-20 21:25:23', 'Y'),
('114.5.248.83', 1, '2020-04-20 22:29:15', 'Y'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'Y'),
('114.5.216.246', 7, '2020-04-21 21:17:56', 'Y'),
('114.5.216.246', 7, '2020-04-21 21:30:23', 'Y'),
('114.5.216.246', 7, '2020-04-21 21:38:02', 'Y'),
('114.5.216.246', 7, '2020-04-21 22:20:43', 'Y'),
('114.5.216.246', 7, '2020-04-21 22:52:35', 'Y'),
('114.5.216.246', 11, '2020-04-22 22:00:34', 'Y'),
('114.5.216.246', 11, '2020-04-22 22:32:36', 'Y'),
('114.5.216.246', 11, '2020-04-22 22:34:18', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT 'administrator',
  `password` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL DEFAULT 'admin',
  `alamat` text NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `blokir` enum('Y','N') NOT NULL DEFAULT 'N',
  `id_session` varchar(100) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama_lengkap`, `level`, `alamat`, `no_telp`, `email`, `blokir`, `id_session`) VALUES
(2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin SMP MTSS PUI Maja', 'admin', 'Majalengka', '081546405120', 'mtsspuimaja@gmail.com', 'N', '9ceb0c0347d35a8b418a7bb5a3f879ff');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL DEFAULT '',
  `to` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `recd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `file_materi`
--

CREATE TABLE IF NOT EXISTS `file_materi` (
  `id_file` int(7) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `id_kelas` varchar(5) NOT NULL,
  `id_matapelajaran` varchar(5) NOT NULL,
  `nama_file` varchar(100) NOT NULL,
  `tgl_posting` date NOT NULL,
  `pembuat` varchar(50) NOT NULL,
  `hits` int(3) NOT NULL,
  PRIMARY KEY (`id_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `file_materi`
--

INSERT INTO `file_materi` (`id_file`, `judul`, `id_kelas`, `id_matapelajaran`, `nama_file`, `tgl_posting`, `pembuat`, `hits`) VALUES
(1, 'Materi Agama', 'K7a', 'AGK7a', 'KONSEP AGAMA.pdf', '2020-04-20', '1', 0),
(2, 'Bahasa inggris 2', 'k9a', 'Bi29', '', '2020-04-20', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jawaban`
--

CREATE TABLE IF NOT EXISTS `jawaban` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `id_tq` int(50) NOT NULL,
  `id_quiz` int(50) NOT NULL,
  `id_siswa` int(50) NOT NULL,
  `jawaban` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `jawaban`
--

INSERT INTO `jawaban` (`id`, `id_tq`, `id_quiz`, `id_siswa`, `jawaban`) VALUES
(1, 1, 1, 1, ''),
(2, 1, 1, 7, 'enam\r\n'),
(3, 1, 1, 11, '4\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_kelas` varchar(5) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `id_pengajar` int(9) NOT NULL,
  `id_siswa` int(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id`, `id_kelas`, `nama`, `id_pengajar`, `id_siswa`) VALUES
(28, 'K7a', 'Kelas VII-A', 1, 5),
(29, 'K7b', 'Kelas VII-B', 2, 1),
(30, 'K7c', 'Kelas VII-C', 3, 3),
(32, 'K8a', 'Kelas VIII-A', 3, 2),
(33, 'k9a', 'Kelas IX-A', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `mata_pelajaran`
--

CREATE TABLE IF NOT EXISTS `mata_pelajaran` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_matapelajaran` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `id_kelas` varchar(5) NOT NULL,
  `id_pengajar` int(9) NOT NULL,
  `deskripsi` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_kelas` (`id_kelas`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mata_pelajaran`
--

INSERT INTO `mata_pelajaran` (`id`, `id_matapelajaran`, `nama`, `id_kelas`, `id_pengajar`, `deskripsi`) VALUES
(1, 'AGK7a', 'Agama', 'K7a', 1, 'Agama Kelas VII-A'),
(2, 'AGK7b', 'Agama', 'K7b', 1, 'Agama Kelas VII-B'),
(3, 'BIK7a', 'Bahasa Indonesia', 'K7a', 2, 'Bahasa Indonesia Kelas 7a'),
(4, 'BIK7b', 'Bahasa Indonesia', 'K7b', 2, 'Bahasa Indonesia Kelas 7b'),
(5, 'Bi29', 'Bahasa Inggris 2', 'k9a', 1, 'Bahasa inggris 9a');

-- --------------------------------------------------------

--
-- Table structure for table `modul`
--

CREATE TABLE IF NOT EXISTS `modul` (
  `id_modul` int(5) NOT NULL AUTO_INCREMENT,
  `nama_modul` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `link` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `static_content` text COLLATE latin1_general_ci NOT NULL,
  `gambar` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `publish` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `status` enum('pengajar','admin') COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'Y',
  `urutan` int(5) NOT NULL,
  `link_seo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_modul`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `modul`
--

INSERT INTO `modul` (`id_modul`, `nama_modul`, `link`, `static_content`, `gambar`, `publish`, `status`, `aktif`, `urutan`, `link_seo`) VALUES
(1, 'Manajemen Admin', '?module=admin', '', '', 'N', 'admin', 'N', 2, ''),
(2, 'Materi', '?module=materi', '', '', 'N', 'pengajar', 'Y', 6, 'semua-berita.html'),
(3, 'Manajemen Siswa', '?module=siswa', '', 'gedungku.jpg', 'Y', 'admin', 'Y', 3, 'profil-kami.html'),
(4, 'Manajemen Modul', '?module=modul', '', '', 'N', 'admin', 'N', 1, ''),
(5, 'Mata Pelajaran', '?module=matapelajaran', '', '', 'Y', 'pengajar', 'Y', 5, ''),
(6, 'Manajemen Quiz', '?module=quiz', '', '', 'N', 'pengajar', 'Y', 7, ''),
(7, 'Manajemen Kelas', ' ?module=kelas', '', '', 'N', 'pengajar', 'Y', 4, 'semua-agenda.html'),
(8, 'Registrasi Siswa', '?module=registrasi', '', '', 'Y', 'admin', 'Y', 8, ''),
(9, 'Laporan Absensi', '?module=laporanabsensi', '', '', 'Y', 'pengajar', 'Y', 9, ''),
(10, 'Laporan Nilai', '?module=laporannilai', '', '', 'Y', 'pengajar', 'Y', 10, '');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE IF NOT EXISTS `nilai` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `id_tq` int(50) NOT NULL,
  `id_siswa` int(50) NOT NULL,
  `benar` int(10) NOT NULL,
  `salah` int(10) NOT NULL,
  `tidak_dikerjakan` int(50) NOT NULL,
  `persentase` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id`, `id_tq`, `id_siswa`, `benar`, `salah`, `tidak_dikerjakan`, `persentase`) VALUES
(1, 1, 1, 1, 4, 0, 20),
(2, 1, 7, 5, 1, 1, 71),
(3, 1, 11, 1, 6, 0, 14);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_soal_esay`
--

CREATE TABLE IF NOT EXISTS `nilai_soal_esay` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `id_tq` int(50) NOT NULL,
  `id_siswa` int(50) NOT NULL,
  `nilai` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `nilai_soal_esay`
--

INSERT INTO `nilai_soal_esay` (`id`, `id_tq`, `id_siswa`, `nilai`) VALUES
(1, 1, 1, '10'),
(2, 1, 7, '100'),
(3, 1, 11, '10');

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `ip` varchar(20) NOT NULL,
  `id_siswa` int(50) NOT NULL,
  `tanggal` datetime NOT NULL,
  `online` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `online`
--

INSERT INTO `online` (`ip`, `id_siswa`, `tanggal`, `online`) VALUES
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 1, '2020-04-21 21:15:44', 'T'),
('114.5.216.246', 7, '2020-04-21 22:52:35', 'T'),
('114.5.216.246', 11, '2020-04-22 22:34:18', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `pengajar`
--

CREATE TABLE IF NOT EXISTS `pengajar` (
  `id_pengajar` int(9) NOT NULL AUTO_INCREMENT,
  `nip` char(12) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username_login` varchar(100) NOT NULL,
  `password_login` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL DEFAULT 'pengajar',
  `alamat` text NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `agama` varchar(20) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `foto` varchar(100) NOT NULL,
  `website` varchar(100) DEFAULT NULL,
  `jabatan` varchar(200) NOT NULL,
  `blokir` enum('Y','N') NOT NULL DEFAULT 'N',
  `id_session` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pengajar`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pengajar`
--

INSERT INTO `pengajar` (`id_pengajar`, `nip`, `nama_lengkap`, `username_login`, `password_login`, `level`, `alamat`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `agama`, `no_telp`, `email`, `foto`, `website`, `jabatan`, `blokir`, `id_session`) VALUES
(1, '10101010102', 'Amiruddin S.Ag', 'amiruddin', '097e20b79a9d707245c2aba5d231b909', 'pengajar', 'Jln. Kartini No.102 - Majalengka', 'Surabaya', '1989-10-23', 'L', 'Islam', '085228482669', 'amiruddin@gmail.com', 'foto.jpg', 'www.amiruddin.com', 'Kepala Sekolah', 'N', '7e2d99bad4b2447bd0c34c37bb4b6d60'),
(2, '10101010103', 'Rina Agustin', 'rina', '3aea9516d222934e35dd30f142fda18c', 'pengajar', '', '', '1990-08-03', 'P', 'Islam', '', '', '', 'http://', 'Guru', 'N', '35227322311f800ce1cb9d1ccc8a58fa'),
(3, '10101010104', 'Agus Suryo', 'agus', 'fdf169558242ee051cca1479770ebac3', 'pengajar', '', '', '1983-04-19', 'L', 'Islam', '', '', '', 'http://', '', 'N', '10101010104'),
(4, '1444', 'Jordi Irawan', 'jordi', '83d53db77bff97220353e490bf373403', 'pengajar', 'medan jaya , bunga cirebon', 'medan ', '1967-04-20', 'L', 'Islam', '099383', 'jordi@gmail.com', '', 'http://', 'Guru', 'N', '1444');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_esay`
--

CREATE TABLE IF NOT EXISTS `quiz_esay` (
  `id_quiz` int(9) NOT NULL AUTO_INCREMENT,
  `id_tq` int(9) NOT NULL,
  `pertanyaan` text NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `tgl_buat` date NOT NULL,
  `jenis_soal` varchar(50) NOT NULL DEFAULT 'esay',
  PRIMARY KEY (`id_quiz`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `quiz_esay`
--

INSERT INTO `quiz_esay` (`id_quiz`, `id_tq`, `pertanyaan`, `gambar`, `tgl_buat`, `jenis_soal`) VALUES
(1, 1, 'Rukun Islam ada berapa ?', '', '2020-04-13', 'esay');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_pilganda`
--

CREATE TABLE IF NOT EXISTS `quiz_pilganda` (
  `id_quiz` int(10) NOT NULL AUTO_INCREMENT,
  `id_tq` int(9) NOT NULL,
  `pertanyaan` text NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `pil_a` text NOT NULL,
  `pil_b` text NOT NULL,
  `pil_c` text NOT NULL,
  `pil_d` text NOT NULL,
  `kunci` varchar(1) NOT NULL,
  `tgl_buat` date NOT NULL,
  `jenis_soal` varchar(50) NOT NULL DEFAULT 'pilganda',
  PRIMARY KEY (`id_quiz`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `quiz_pilganda`
--

INSERT INTO `quiz_pilganda` (`id_quiz`, `id_tq`, `pertanyaan`, `gambar`, `pil_a`, `pil_b`, `pil_c`, `pil_d`, `kunci`, `tgl_buat`, `jenis_soal`) VALUES
(1, 1, 'Apakah ini gambar apa?', 'pug-dog-stands-road-looks-lens-114149845.jpg', 'Anjing', 'Babi', 'Monyet', 'Kura-kura', 'A', '2020-04-13', 'pilganda'),
(2, 1, 'Apakah ini gambar?', 'photo_01.jpg', 'Kura-kura', 'Babi', 'Kucing', 'Harimau', 'B', '2020-04-13', 'pilganda'),
(3, 1, 'Apakah ini gambar?', 'buaya.jpg', 'Ular', 'Burung', 'Ulat', 'Buaya', 'D', '2020-04-13', 'pilganda'),
(4, 1, 'Apakah ini gambar?', 'kodok.jpg', 'kodok', 'anjing', 'babi', 'monyet', 'A', '2020-04-13', 'pilganda'),
(5, 1, 'Apakah ini gambar?', 'monyet.jpg', 'kodok', 'anjing', 'babi', 'monyet', 'D', '2020-04-13', 'pilganda'),
(6, 1, 'gambar apa?', 'babi.jpg', 'babi', 'kucing', 'tikus', 'kuda', 'A', '2020-04-13', 'pilganda'),
(7, 1, 'Nabi terakhir adalah?', '', 'Muhammad', 'Isa', 'Musa', 'Ibrahim', 'A', '2020-04-21', 'pilganda');

-- --------------------------------------------------------

--
-- Table structure for table `registrasi_siswa`
--

CREATE TABLE IF NOT EXISTS `registrasi_siswa` (
  `id_registrasi` int(9) NOT NULL AUTO_INCREMENT,
  `nis` varchar(50) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username_login` varchar(50) NOT NULL,
  `password_login` varchar(50) NOT NULL,
  `id_kelas` varchar(5) NOT NULL,
  `jabatan` varchar(200) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `agama` varchar(20) NOT NULL,
  `nama_ayah` varchar(100) NOT NULL,
  `nama_ibu` varchar(100) NOT NULL,
  `th_masuk` varchar(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `blokir` enum('Y','N') NOT NULL,
  `id_session` varchar(100) NOT NULL,
  `id_session_soal` varchar(100) NOT NULL,
  `level` varchar(20) NOT NULL DEFAULT 'siswa',
  PRIMARY KEY (`id_registrasi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `registrasi_siswa`
--

INSERT INTO `registrasi_siswa` (`id_registrasi`, `nis`, `nama_lengkap`, `username_login`, `password_login`, `id_kelas`, `jabatan`, `alamat`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `agama`, `nama_ayah`, `nama_ibu`, `th_masuk`, `email`, `no_telp`, `foto`, `blokir`, `id_session`, `id_session_soal`, `level`) VALUES
(5, '23444', 'benar', '', '', 'K7a', '', 'jkl', 'jogja', '2004-04-22', 'L', 'islam', 'benar', 'benar', '2020', 'benar@gmail.com', '', '', 'Y', '', '', 'siswa');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `id_siswa` int(9) NOT NULL AUTO_INCREMENT,
  `nis` varchar(50) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username_login` varchar(50) NOT NULL,
  `password_login` varchar(50) NOT NULL,
  `id_kelas` varchar(5) NOT NULL,
  `jabatan` varchar(200) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `agama` varchar(20) NOT NULL,
  `nama_ayah` varchar(100) NOT NULL,
  `nama_ibu` varchar(100) NOT NULL,
  `th_masuk` varchar(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `blokir` enum('Y','N') NOT NULL,
  `id_session` varchar(100) NOT NULL,
  `id_session_soal` varchar(100) NOT NULL,
  `level` varchar(20) NOT NULL DEFAULT 'siswa',
  PRIMARY KEY (`id_siswa`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nis`, `nama_lengkap`, `username_login`, `password_login`, `id_kelas`, `jabatan`, `alamat`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `agama`, `nama_ayah`, `nama_ibu`, `th_masuk`, `email`, `no_telp`, `foto`, `blokir`, `id_session`, `id_session_soal`, `level`) VALUES
(1, '99999', 'Hasan', 'hasan', 'fc3f318fba8b3c1502bece62a27712df', 'K7b', 'siswa', 'Delima No.0 Rt 0 Rw 2 Majalengka', 'Bekasi', '2007-08-10', 'L', 'Islam', '--', '--', '2007', 'hasan@yahoo.com', '090909', 'IMG_4186.JPG', 'N', '3cb951e776af166d137a49a9e5309b08', '99999', 'siswa'),
(2, '13112064', 'Hilman ', 'hilman', 'cf081b11e184de45ecce347f758936f9', 'K7b', '', '', '', '2007-03-31', 'L', 'Islam', '', '', '2007', 'hilman@gmail.com', '', '', 'N', '644b9cd1bad12011cf7aac60ab7e52f0', '13112064', 'siswa'),
(3, '10800800', 'Sugianto', 'sugianto', '64209e8f856591b9adb1223cb92af807', 'K7c', 'siswa', 'alamat', 'tempat lahir', '2007-05-15', 'L', 'Islam', 'emboh', 'emboh', '2007', 'sugianto@yahoo.com', '0000', '', 'N', '10800800', '10800800', 'siswa'),
(4, '10800801', 'Siska', 'siska', '21218cca77804d2ba1922c33e0151105', 'K7a', '', 'alamat', 'tempat lahir', '2007-12-28', 'P', 'islam', '--', '--', '2007', 'siska@gmail.com', '', '', 'N', '10800801', '10800801', 'siswa'),
(5, '10800802', 'Syamsul', 'syamsul', '564d5ea829ce8977fb848c0a654c7888', 'K7a', '', 'alamat', 'asdf', '2007-03-10', 'L', 'islam', 'asd', 'asdfgas', '2012', 'syamsul@gmail.com', '', '', 'N', '10800802', '10800802', 'siswa'),
(6, '80000000', 'Fatimah', 'fatimah', '3610528e7fee68c6ffb0445603ef2c8e', 'K7c', 'murid', 'jln jatiwangi majalengka', 'majalengka', '2004-04-20', 'P', 'Islam', 'tikkg ', 'gmhg ', '2019', 'hasnnsn@gmail.com', '08887', '', 'N', '80000000', '80000000', 'siswa'),
(7, '71234455', 'Firman ', 'firman', '74bfebec67d1a87b161e5cbcf6f72a4a', 'K7a', 'murid', 'jln maja utara 20', 'majalengka', '2020-04-20', 'L', 'Islam', 'rosandi', 'tika ', '2019', 'tika@mail.com', '0888777', '', 'N', 'f5dd0d53ff039fabe4fa40a19b13be81', '71234455', 'siswa'),
(8, '0899', 'yaya taure', '0899', '47c8c701a4cd6e769579376af52560cc', 'k9a', '', 'jln cigasong no 1 majalengka', 'majalengka', '2003-04-21', 'L', 'islam', 'tio subroto', 'hesti niken', '2018', 'yaya@gmail.com', '', '', 'Y', '', '', 'siswa'),
(9, '88', 'hikma', '88', '2a38a4a9316c49e5a833517c45d31070', 'k9a', '', 'hdjjdkl', 'jdjjdj', '2014-04-21', 'L', 'islam', 'firza', 'siti', '2020', 'hikma@gmail.com', '', '', 'Y', '', '', 'siswa'),
(10, '4455', 'mantap', '4455', 'd2b15c75c0c389b49c2efbea79cdc946', 'K7a', '', 'bhjdkdk', 'jombang', '2008-04-21', 'L', 'islam', 'herman', 'eka', '2020', 'mantap@gmail.com', '', '', 'N', '4455', '4455', 'siswa'),
(11, '1233', 'aku', 'aku', '89ccfac87d8d06db06bf3211cb2d69ed', 'K7a', '', 'hjfkfk', 'medan', '2020-04-21', 'L', 'islam', 'dddddf', 'hhh', '2019', 'aku@gmail.com', '', '', 'N', 'adbe348c5e06a07756b2a0f0a60f397f', '1233', 'siswa');

-- --------------------------------------------------------

--
-- Table structure for table `siswa_sudah_mengerjakan`
--

CREATE TABLE IF NOT EXISTS `siswa_sudah_mengerjakan` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_tq` int(20) NOT NULL,
  `id_siswa` varchar(200) NOT NULL,
  `dikoreksi` varchar(1) NOT NULL DEFAULT 'B',
  `hits` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `siswa_sudah_mengerjakan`
--

INSERT INTO `siswa_sudah_mengerjakan` (`id`, `id_tq`, `id_siswa`, `dikoreksi`, `hits`) VALUES
(1, 1, '1', 'S', 1),
(2, 1, '7', 'S', 1),
(3, 0, '7', 'B', 1),
(4, 1, '11', 'S', 1);

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id_templates` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pembuat` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `folder` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id_templates`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id_templates`, `judul`, `pembuat`, `folder`, `aktif`) VALUES
(1, 'Standar', 'Pui Maja', 'templates/puimaja', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `topik_quiz`
--

CREATE TABLE IF NOT EXISTS `topik_quiz` (
  `id_tq` int(9) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) NOT NULL,
  `id_kelas` varchar(5) NOT NULL,
  `id_matapelajaran` varchar(10) NOT NULL,
  `tgl_buat` date NOT NULL,
  `pembuat` varchar(100) NOT NULL,
  `waktu_pengerjaan` int(50) NOT NULL,
  `info` text NOT NULL,
  `terbit` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_tq`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `topik_quiz`
--

INSERT INTO `topik_quiz` (`id_tq`, `judul`, `id_kelas`, `id_matapelajaran`, `tgl_buat`, `pembuat`, `waktu_pengerjaan`, `info`, `terbit`) VALUES
(1, 'kuis', 'K7a', 'AGK7a', '2020-04-21', '1', 3600, 'apakah b', 'Y'),
(2, 'bahasa inggirs dasar', 'k9a', 'Bi29', '2020-04-21', '1', 3600, 'kuis bahasa inggris 2 untuk kelas 9 a', 'Y'),
(3, 'rukun islam', 'K7a', 'AGK7a', '2020-04-21', '1', 3000, 'harus dikerjakan', 'N');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
