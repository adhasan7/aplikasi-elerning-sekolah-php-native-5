<script>
function confirmdelete(delUrl) {
if (confirm("Anda yakin ingin menghapus?")) {
document.location = delUrl;
}
}
</script>
 
<script language="JavaScript" type="text/JavaScript">

 function showpel()
 {
 <?php

 // membaca semua kelas
 $query = "SELECT * FROM kelas";
 $hasil = mysql_query($query);

 // membuat if untuk masing-masing pilihan kelas beserta isi option untuk combobox kedua
 while ($data = mysql_fetch_array($hasil))
 {
   $idkelas = $data['id_kelas'];

   // membuat IF untuk masing-masing kelas
   echo "if (document.form_video.id_kelas.value == \"".$idkelas."\")";
   echo "{";

   // membuat option matapelajaran untuk masing-masing kelas
   $query2 = "SELECT * FROM mata_pelajaran WHERE id_kelas = '$idkelas'";
   $hasil2 = mysql_query($query2);
   $content = "document.getElementById('pelajaran').innerHTML = \"<select name='".id_matapelajaran."'>";
   while ($data2 = mysql_fetch_array($hasil2))
   {
       $content .= "<option value='".$data2['id_matapelajaran']."'>".$data2['nama']."</option>";
   }
   $content .= "</select>\";";
   echo $content;
   echo "}\n";
 }

 ?>
 }

 function showpel_pengajar()
 {
 <?php

 // membaca semua kelas
 $query1 = "SELECT * FROM kelas";
 $hasil1 = mysql_query($query1);

 // membuat if untuk masing-masing pilihan kelas beserta isi option untuk combobox kedua
 while ($data1 = mysql_fetch_array($hasil1))
 {
   $idkelas = $data1['id_kelas'];

   // membuat IF untuk masing-masing kelas
   echo "if (document.form_video_pengajar.id_kelas.value == \"".$idkelas."\")";
   echo "{";

   // membuat option matapelajaran untuk masing-masing kelas
   $query2 = "SELECT * FROM mata_pelajaran WHERE  id_kelas = '$idkelas' AND id_pengajar ='$_SESSION[idpengajar]' ";
   $hasil2 = mysql_query($query2);
   $content = "document.getElementById('pelajaran_pengajar').innerHTML = \"<select name='".id_matapelajaran."'>";
   while ($data2 = mysql_fetch_array($hasil2))
   {
       $content .= "<option value='".$data2['id_matapelajaran']."'>".$data2['nama']."</option>";
   }
   $content .= "</select>\";";
   echo $content;
   echo "}\n";
 }

 ?>
 }
</script>
<?php
function fsize($file){
                            $a = array("B", "KB", "MB", "GB", "TB", "PB");
                            $pos = 0;
                            $size = filesize($file);
                            while ($size >= 1024)
                            {
                            $size /= 1024;
                            $pos++;
                            }
                            return round ($size,2)." ".$a[$pos];
                            }
?>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{



$aksi="modul/mod_video/aksi_video.php";
switch($_GET[act]){
  // Tampil kelas
  default:
    if ($_SESSION[leveluser]=='admin' OR $_SESSION[leveluser]=='pengajar'){                        
        if ($_SESSION[leveluser]=='admin' ){        
            $cek_video = mysql_query("SELECT * FROM video ORDER BY id_kelas");
        }else{
            $cek_video = mysql_query("SELECT * FROM video WHERE pembuat = '$_SESSION[idpengajar]'");
        }
     echo "<h2>Daftar Link Video Tutorial</h2><hr>
          <input class='button blue' type=button value='Tambah Video' onclick=\"window.location.href='?module=video&act=tambahvideo';\">";
     echo "<br><br><table id='table1' class='gtable sortable'><thead>
          <tr><th>No</th><th>Judul</th><th>Kelas</th><th>Pelajaran</th><th>Link Video</th><th>Tgl Upload</th><th>Hits</th><th>Aksi</th></tr></thead>";

    $no=1;
    while ($r=mysql_fetch_array($cek_video)){
      $tgl_posting   = tgl_indo($r[tgl_posting]);
      $tgl_batas   = tgl_indo($r[tgl_batas_upload]);
       echo "<tr><td>$no</td>
             <td>$r[judul]</td>";
             $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$r[id_kelas]'");
             $cek_kelas = mysql_num_rows($kelas);
             if(!empty($cek_kelas)){
             while($k=mysql_fetch_array($kelas)){
                 echo "<td><a href=?module=kelas&act=detailkelas&id=$r[id_kelas] title='Detail Kelas'>$k[nama]</td>";
             }
             }else{
                 echo"<td></td>";
             }
             $pelajaran = mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$r[id_matapelajaran]'");
             $cek_pelajaran = mysql_num_rows($pelajaran);
             if(!empty($cek_pelajaran)){
             while($p=mysql_fetch_array($pelajaran)){
                echo "<td><a href=?module=matapelajaran&act=detailpelajaran&id=$r[id_matapelajaran] title='Detail pelajaran'>$p[nama]</a></td>";
             }
             }else{
                 echo"<td></td>";
             }

             echo "<td>$r[link_video]</td>
             <td>$tgl_posting</td>             
             <td>$r[hits]</td>
             <td><a href='?module=video&act=editvideo&id=$r[id_video]' title='Edit'><img src='images/icons/edit.png' alt='Edit' /></a>  |
            <a href=javascript:confirmdelete('$aksi?module=video&act=hapus&id=$r[id_video]') title='Hapus'><img src='images/icons/cross.png' alt='Delete' /></a>
                </td></tr>";
                 

     $no++;
    }
    echo"</table>";   
    
    }
    
    else{
        echo"<br><b class='judul'>Video</b><br><p class='garisbawah'></p>";

        $ambil_siswa = mysql_query("SELECT * FROM siswa WHERE id_siswa = '$_SESSION[idsiswa]'");
        $data_siswa = mysql_fetch_array($ambil_siswa);

        $mapel = mysql_query("SELECT * FROM mata_pelajaran WHERE id_kelas = '$data_siswa[id_kelas]'");
       echo "<table>
          <tr><th>No</th><th>Mata Pelajaran</th><th>Video</th></tr>";
        $no=1;
        while ($r=mysql_fetch_array($mapel)){
        echo "<tr><td>$no</td>
             <td>$r[nama]</td>";
             echo "<td><input type=button class='tombol' value='Lihat Link Video'
                       onclick=\"window.location.href='?module=video&act=daftarvideo&id=$r[id_matapelajaran]';\"></td></tr>";
        $no++;
        }
        echo "</table>";


    }
    break;


case "daftarvideo":
    if ($_SESSION[leveluser] == 'siswa'){
        
        $p      = new Paging;
        $batas  = 5;
        $posisi = $p->cariPosisi($batas);

        $mapel = mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$_GET[id]'");
        $data_mapel = mysql_fetch_array($mapel);
        $video = mysql_query("SELECT * FROM video WHERE id_matapelajaran = '$_GET[id]' LIMIT $posisi,$batas ");
        $cek_video = mysql_num_rows($video);
        if (!empty($cek_video)){
        echo"<br><b class='judul'>Daftar Link Video $data_mapel[nama] </b><br><p class='garisbawah'></p>";
        echo "<table>";
        $no=$posisi+1;
        while ($r=mysql_fetch_array($video)){
        echo "<tr><td rowspan='4'>$no</td>";
        echo "<td rowspan='4'><img src='../images/youtube.png'></td>";
             echo "<td>Judul</td><td>: $r[judul]</td></tr>
             <tr><td>Link Video</td><td>: $r[link_video]</td></tr>
             <tr><td>Tanggal Posting</td><td>: $r[tgl_posting]</td></tr>
             <tr><td colspan=2><input type=button class='tombol' value='Buka Video'
                       onclick=\"window.location.href='openvideo.php?id=$r[id_video]&linkvideo=$r[link_video]';\">
                       <b class='judul'>Dibuka : $r[hits] kali</b></td></tr>";

        $no++;
        }
        echo "</table>";
        $jmldata=mysql_num_rows(mysql_query("SELECT * FROM video WHERE id_matapelajaran = '$_GET[id]'"));
        $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
        $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

        echo "<div id=paging>$linkHalaman</div><br>";

        echo "<p class='garisbawah'></p><input type=button class='tombol' value='Kembali'
          onclick=self.history.back()>";
    }
    else{
        echo "<script>window.alert('Tidak ada file video di mata pelajaran ini?');
            window.location=(href='media.php?module=video')</script>";
    }
    }
    break;

case "tambahvideo":
    if ($_SESSION[leveluser]=='admin'){
    echo "<form name='form_video' method=POST action='$aksi?module=video&act=input_video'>
     <fieldset>
     <legend>Tambah Video</legend>
     <dl class='inline'>
    <dt><label>Judul</label></dt>              <dd><input type=text name='judul' size=50></dd>
    <dt><label>Kelas</label></dt>              <dd><select name='id_kelas' onChange='showpel()'>
                                          <option value=''>-pilih-</option>";                                          
                                          $cari_kelas = mysql_query("SELECT * FROM kelas ORDER BY nama");
                                          while ($k=mysql_fetch_array($cari_kelas)){
                                          echo"<option value='".$k[id_kelas]."'>".$k[nama]."</option>";
                                          }                                          
                                          echo"</select></dd>
    <dt><label>Pelajaran</label></dt>          <dd><div id='pelajaran'></div></dd>
    <dt><label>Link Video</label></dt>               <dd><input type=text name='linkvideo' size=50></dd>
    </dl>
          
          <p align=center><input class='button blue' type=submit value=Simpan>
          <input class='button blue' type=button value=Batal onclick=self.history.back()></p>
          
          </fieldset></form>";
    }else{
    echo "
    <form name='form_video_pengajar' method=POST action='$aksi?module=video&act=input_video'>
    <fieldset>
    <legend>Tambah video</legend>
    <dl class='inline'>
    <dt><label>Judul</label></dt>              <dd> <input type=text name='judul' size=50></dd>
    <dt><label>Kelas</label></dt>              <dd> <select name='id_kelas' onChange='showpel_pengajar()'>
                                          <option value='0' selected>-pilih-</option>";
                                          $pilih= mysql_query("SELECT DISTINCT id_kelas FROM mata_pelajaran WHERE id_pengajar ='$_SESSION[idpengajar]'");
                                          while($row=mysql_fetch_array($pilih)){
                                          $cari_kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$row[id_kelas]'");
                                          while ($k=mysql_fetch_array($cari_kelas)){
                                          echo"<option value='".$k[id_kelas]."'>".$k[nama]."</option>";
                                          }
                                          }
                                          echo"</select></dd>
    <dt><label>Pelajaran</label></dt>          <dd> <div id='pelajaran_pengajar'></div></dd>
    <dt><label>Link Video</label></dt>              <dd> <input type=text name='linkvideo' size=50></dd>
    <p align=center><input class='button blue' type=submit value=Simpan>
                      <input class='button blue' type=button value=Batal onclick=\"window.location.href='?module=video';\"></p>
    </dl></fieldset></form>";
    }
    break;

case "editvideo":
    if ($_SESSION[leveluser]=='admin'){
    $edit=mysql_query("SELECT * FROM video WHERE id_video = '$_GET[id]'");
    $m=mysql_fetch_array($edit);
    $isikelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$m[id_kelas]'");
    $k=mysql_fetch_array($isikelas);
    $pelajaran = mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$m[id_matapelajaran]'");
    $p=mysql_fetch_array($pelajaran);

    echo "
    <form name='form_video' method=POST action='$aksi?module=video&act=edit_video'>
    <input type=hidden name=id value='$m[id_video]'>
    <fieldset>
     <legend>Edit video</legend>
     <dl class='inline'>
    <dt><label>Judul</label></dt>             <dd>: <input type=text name='judul' value='$m[judul]'></dd>
    <dt><label>Kelas</label></dt>               <dd>: <select name='id_kelas' onChange='showpel()'>
                                          <option value='".$k[id_kelas]."' selected>".$k[nama]."</option>";
                                          $pilih="SELECT * FROM kelas ORDER BY nama";
                                          $query=mysql_query($pilih);
                                          while($row=mysql_fetch_array($query)){
                                          echo"<option value='".$row[id_kelas]."'>".$row[nama]."</option>";
                                          }
                                          echo"</select></dd>
    <dt><label>Pelajaran</label></dt>           <dd>: <select id='pelajaran' name='id_matapelajaran'>
                                          <option value='".$p[id_matapelajaran]."' selected>".$p[nama]."</option>
                                          </select></dd>
    <dt><label>Link Video</label></dt>         <dd>: <input type=text name='linkvideo' value='$m[link_video]' size=70>
    </dl>

          <p align=center><input class='button blue' type=submit value=Update>
          <input class='button blue' type=button value=Batal onclick=self.history.back()></p>

          </fieldset></form>";
    }
    else{
    $edit=mysql_query("SELECT * FROM video WHERE id_video = '$_GET[id]'");
    $m=mysql_fetch_array($edit);
    $isikelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$m[id_kelas]'");
    $k=mysql_fetch_array($isikelas);
    $pelajaran = mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$m[id_matapelajaran]'");
    $p=mysql_fetch_array($pelajaran);

    echo "<form name='form_video_pengajar' method=POST action='$aksi?module=video&act=edit_video'>
    <input type=hidden name=id value='$m[id_video]'>
    <fieldset>
    <legend>Edit video</legend>
    <dl class='inline'>
    <dt><label>Judul</label></dt>              <dd>: <input type=text name='judul' value='$m[judul]' size=50></dd>
    <dt><label>Kelas</label></dt>              <dd>: <select name='id_kelas' onChange='showpel_pengajar()'>
                                          <option value='".$k[id_kelas]."' selected>".$k[nama]."</option>";
                                          $pilih="SELECT * FROM kelas WHERE id_pengajar = '$_SESSION[idpengajar]'";
                                          $query=mysql_query($pilih);
                                          while($row=mysql_fetch_array($query)){
                                          echo"<option value='".$row[id_kelas]."'>".$row[nama]."</option>";
                                          }
                                          echo"</select></dd>
    <dt><label>Pelajaran</label></dt>          <dd>: <select id='pelajaran_pengajar' name='id_matapelajaran'>
                                          <option value='".$p[id_matapelajaran]."' selected>".$p[nama]."</option>
                                          </select></dd>
    <dt><label>Link Video</label></dt>         <dd>: <input type=text name='linkvideo' value='$m[link_video]' size=70>
    <p align=center><input class='button blue' type=submit value=Simpan>
                      <input class='button blue' type=button value=Batal onclick=self.history.back()></p>
    </dl></fieldset></form>";
    }
    break;

}
}
?>