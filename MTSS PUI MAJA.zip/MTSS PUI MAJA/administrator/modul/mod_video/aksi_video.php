<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../configurasi/koneksi.php";
include "../../../configurasi/library.php";

$module=$_GET['module'];
$act=$_GET['act'];

if ($module=='video' AND $act=='input_video'){

  //cari pembuat
  $pelajaran = mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$_POST[id_matapelajaran]'");
  $data_mapel = mysql_fetch_array($pelajaran);
  $pengajar = mysql_query("SELECT * FROM pengajar WHERE id_pengajar = '$data_mapel[id_pengajar]'");
  $cek_pengajar = mysql_num_rows($pengajar);
  if(!empty($cek_pengajar)){
                    mysql_query("INSERT INTO video(judul,
                                    id_kelas,
                                    id_matapelajaran,
                                    link_video,
                                    tgl_posting,
                                    pembuat)
                            VALUES('$_POST[judul]',
                                   '$_POST[id_kelas]',
                                   '$_POST[id_matapelajaran]',
                                   '$_POST[linkvideo]',
                                   '$tgl_sekarang',
                                   '$data_mapel[id_pengajar]')");
                    header('location:../../media_admin.php?module='.$module);
  }
}

elseif($module=='video' AND $act=='edit_video'){

  //cari pembuat
  $pelajaran = mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$_POST[id_matapelajaran]'");
  $data_mapel = mysql_fetch_array($pelajaran);
  $pengajar = mysql_query("SELECT * FROM pengajar WHERE id_pengajar = '$data_mapel[id_pengajar]'");
  $cek_pengajar = mysql_num_rows($pengajar);
  if(!empty($cek_pengajar)){
                    mysql_query("UPDATE video SET judul = '$_POST[judul]',
                                    id_kelas = '$_POST[id_kelas]',
                                    id_matapelajaran = '$_POST[id_matapelajaran]',
                                    link_video = '$_POST[linkvideo]',
                                    pembuat = '$data_mapel[id_pengajar]'
                            WHERE id_video = '$_POST[id]'");
                    header('location:../../media_admin.php?module='.$module);
  }
}

elseif($module=='video' AND $act=='hapus'){
                    mysql_query("DELETE FROM video WHERE id_video = '$_GET[id]'");
  header('location:../../media_admin.php?module='.$module);
}

}
?>