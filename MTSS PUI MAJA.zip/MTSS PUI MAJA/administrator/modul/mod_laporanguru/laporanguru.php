<script>
function confirmdelete(delUrl) {
if (confirm("Anda yakin ingin menghapus?")) {
document.location = delUrl;
}
}
</script>
<script language="JavaScript" type="text/JavaScript">

 function showpel()
 {
 <?php

 // membaca semua kelas
 $query = "SELECT * FROM absensi";
 $hasil = mysql_query($query);

 // membuat if untuk masing-masing pilihan nilai beserta isi option untuk combobox kedua
 while ($data = mysql_fetch_array($hasil))
 {
   $idguru = $data['id_guru'];

   // membuat IF untuk masing-masing nilai
   echo "if (document.form_laporan.id_guru.value == \"".$idguru."\")";
   echo "{";

   // membuat option matapelajaran untuk masing-masing nilai
   $query2 = "SELECT * FROM guru WHERE id_guru = '$idguru'";
   $hasil2 = mysql_query($query2);
   $content = "document.getElementById('pelajaran').innerHTML = \"<select name='".id_matapelajaran."'>";
   while ($data2 = mysql_fetch_array($hasil2))
   {
       $content .= "<option value='".$data2['id_matapelajaran']."'>".$data2['nama']."</option>";
   }
   $content .= "</select>\";";
   echo $content;
   echo "}\n";
 }

 ?>
 }
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

$aksi="modul/mod_laporanguru/aksi_laporanguru.php";
switch($_GET[act]){
// Tampil Mata Pelajaran
  default:
    if ($_SESSION[leveluser]=='admin'){
      $tampil_guru = mysql_query("SELECT nip,nama_lengkap,alamat,jenis_kelamin,tgl_lahir,no_telp FROM guru");
      echo "<h2>Laporan Daftar Guru</h2><hr>
          <input class='button blue' type=button value='Cetak Laporan' onclick=\"window.location.href='$aksi?module=laporanguru&act=cetaklaporan';\">";
          echo "<br><br><table id='table1' class='gtable sortable'><thead>
          <tr><th>No</th><th>NIP</th><th>Nama</th><th>Alamat</th><th>JK</th><th>Tgl. Lahir</th><th>No. Telepon</th></tr></thead>";
    $no=1;
    while ($r=mysql_fetch_array($tampil_guru)){
       echo "<tr><td>$no</td>
             <td>$r[nip]</td>            
             <td>$r[nama_lengkap]</td>            
             <td>$r[alamat]</td>
             <td>$r[jenis_kelamin]</td>
             <td>$r[tgl_lahir]</td>
             <td>$r[no_telp]</td>";
      $no++;
    }
    echo "</table>";
    }
    elseif ($_SESSION[leveluser]=='guru'){
         echo"<h2>Kelas Yang Anda Ajar</h2><hr>
         <input type=button class='button blue' value='Cetak Semua' onclick=\"window.location.href='$aksi?module=laporanguru&act=cetaklaporan';\">";

         $tampil_kelas = mysql_query("SELECT * FROM kelas WHERE id_guru = '$_SESSION[idguru]'");
         $ketemu=mysql_num_rows($tampil_kelas);
         if (!empty($ketemu)){
                echo "<br><br><table id='table1' class='gtable sortable'><thead>
                <tr><th>No</th><th>Kelas</th><th>Wali Kelas</th><th>Ketua Kelas</th><th>Aksi</th></tr></thead>";

                $no=1;
                while ($r=mysql_fetch_array($tampil_kelas)){
                    echo "<tr><td>$no</td>
                    <td>$r[nama]</td>";
                    $kelas=$r[nama];
                    
                    $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$_SESSION[idguru]'");
                    $ada_guru = mysql_num_rows($guru);
                    if(!empty($ada_guru)){
                    while($p=mysql_fetch_array($guru)){
                            echo "<td>$p[nama_lengkap]</td>";
                    }
                    }else{
                            echo "<td></td>";
                    }

                    $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$r[id_guru]'");
                    $ada_guru = mysql_num_rows($guru);
                    if(!empty($ada_guru)){
                    while ($s=mysql_fetch_array($guru)){
                            echo"<td>$s[nama_lengkap]</td>";
                     }
                    }else{
                            echo"<td></td>";
                    }

                    echo "<td><input class='button small white' type=button value='Cetak Nilai Kelas $kelas' onclick=\"window.location.href='$aksi?module=laporanguru&act=cetaklaporankelas&kelas=$kelas';\"></td>";
                $no++;
                }
                echo "</table>";
                }else{
                    echo "<script>window.alert('Tidak ada kelas yang anda ajar,kembali ke home untuk menambah');
                    window.location=(href='?module=home')</script>";
                }
    }
}
}
?>