<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../configurasi/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
$kelas=$_GET[kelas];

// Input mapel
if ($module=='laporanguru' AND $act=='cetaklaporan'){
    if ($_SESSION[leveluser]=='admin'){
      $tampil_guru = mysql_query("SELECT nip,nama_lengkap,alamat,jenis_kelamin,tgl_lahir,no_telp FROM guru");
    }elseif ($_SESSION[leveluser]=='guru'){
      $tampil_guru = mysql_query("SELECT nip,nama_lengkap,alamat,jenis_kelamin,tgl_lahir,no_telp FROM guru");
    }
	echo "<div class='logo clear'><img src='../../../images/logo.png' alt='Logo Aksi' width='100' height='100' /></div>";
      echo "<h2>Laporan Daftar Guru</h2><hr>";
          echo "<br><br><table border='1' style='width: 100%'><thead>
          <tr><th>No</th><th>NIP</th><th>Nama</th><th>Alamat</th><th>JK</th><th>Tgl. Lahir</th><th>No. Telp</th></tr></thead>";
    $no=1;
    while ($r=mysql_fetch_array($tampil_guru)){
       echo "<tr><td>$no</td>
             <td>$r[nip]</td>            
             <td>$r[nama_lengkap]</td>            
             <td>$r[alamat]</td>
             <td>$r[jenis_kelamin]</td>
             <td>$r[tgl_lahir]</td>
             <td>$r[no_telp]</td>";
      $no++;
    }
    echo "</table>";
	
    echo "<script>
		window.print();
	</script>";
        
}

}
?>