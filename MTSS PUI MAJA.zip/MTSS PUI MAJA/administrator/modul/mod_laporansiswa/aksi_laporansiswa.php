<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../configurasi/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];
$kelas=$_GET[kelas];

// Input mapel
if ($module=='laporansiswa' AND $act=='cetaklaporan'){
    if ($_SESSION[leveluser]=='admin'){
      $tampil_siswa = mysql_query("SELECT s.nis,s.nama_lengkap,k.nama,s.jenis_kelamin,s.tgl_lahir,s.no_telp FROM siswa s INNER JOIN kelas k ON k.id_kelas=s.id_kelas");
    }elseif ($_SESSION[leveluser]=='guru'){
      $tampil_siswa = mysql_query("SELECT s.nis,s.nama_lengkap,k.nama,s.jenis_kelamin,s.tgl_lahir,s.no_telp FROM siswa s INNER JOIN kelas k ON k.id_kelas=s.id_kelas");
    }
	echo "<div class='logo clear'><img src='../../../images/logo.png' alt='Logo Aksi' width='100' height='100' /></div>";
      echo "<h2>Laporan Daftar Siswa</h2><hr>";
          echo "<br><br><table border='1' style='width: 100%'><thead>
          <tr><th>No</th><th>NIS</th><th>Nama</th><th>Kelas</th><th>JK</th><th>Tgl. Lahir</th><th>No. Telp</th></tr></thead>";
    $no=1;
    while ($r=mysql_fetch_array($tampil_siswa)){
       echo "<tr><td>$no</td>
             <td>$r[nis]</td>            
             <td>$r[nama_lengkap]</td>            
             <td>$r[nama]</td>
             <td>$r[jenis_kelamin]</td>
             <td>$r[tgl_lahir]</td>
             <td>$r[no_telp]</td>";
      $no++;
    }
    echo "</table>";
	
    echo "<script>
		window.print();
	</script>";
        
}

}
?>