<script>
function confirmdelete(delUrl) {
if (confirm("Anda yakin ingin menghapus?")) {
document.location = delUrl;
}
}
</script>
<script language="JavaScript" type="text/JavaScript">

 function showpel()
 {
 <?php

 // membaca semua kelas
 $query = "SELECT * FROM absensi";
 $hasil = mysql_query($query);

 // membuat if untuk masing-masing pilihan nilai beserta isi option untuk combobox kedua
 while ($data = mysql_fetch_array($hasil))
 {
   $idsiswa = $data['id_siswa'];

   // membuat IF untuk masing-masing nilai
   echo "if (document.form_laporan.id_siswa.value == \"".$idsiswa."\")";
   echo "{";

   // membuat option matapelajaran untuk masing-masing nilai
   $query2 = "SELECT * FROM siswa WHERE id_siswa = '$idsiswa'";
   $hasil2 = mysql_query($query2);
   $content = "document.getElementById('pelajaran').innerHTML = \"<select name='".id_matapelajaran."'>";
   while ($data2 = mysql_fetch_array($hasil2))
   {
       $content .= "<option value='".$data2['id_matapelajaran']."'>".$data2['nama']."</option>";
   }
   $content .= "</select>\";";
   echo $content;
   echo "}\n";
 }

 ?>
 }
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

$aksi="modul/mod_laporansiswa/aksi_laporansiswa.php";
switch($_GET[act]){
// Tampil Mata Pelajaran
  default:
    if ($_SESSION[leveluser]=='admin'){
      $tampil_siswa = mysql_query("SELECT s.nis,s.nama_lengkap,k.nama,s.jenis_kelamin,s.tgl_lahir,s.no_telp FROM siswa s INNER JOIN kelas k ON k.id_kelas=s.id_kelas");
      echo "<h2>Laporan Daftar Siswa</h2><hr>
          <input class='button blue' type=button value='Cetak Laporan' onclick=\"window.location.href='$aksi?module=laporansiswa&act=cetaklaporan';\">";
          echo "<br><br><table id='table1' class='gtable sortable'><thead>
          <tr><th>No</th><th>NIS</th><th>Nama</th><th>Kelas</th><th>JK</th><th>Tgl. Lahir</th><th>No. Telepon</th></tr></thead>";
    $no=1;
    while ($r=mysql_fetch_array($tampil_siswa)){
       echo "<tr><td>$no</td>
             <td>$r[nis]</td>            
             <td>$r[nama_lengkap]</td>            
             <td>$r[nama]</td>
             <td>$r[jenis_kelamin]</td>
             <td>$r[tgl_lahir]</td>
             <td>$r[no_telp]</td>";
      $no++;
    }
    echo "</table>";
    }
    elseif ($_SESSION[leveluser]=='guru'){
         echo"<h2>Kelas Yang Anda Ajar</h2><hr>
         <input type=button class='button blue' value='Cetak Semua' onclick=\"window.location.href='$aksi?module=laporansiswa&act=cetaklaporan';\">";

         $tampil_kelas = mysql_query("SELECT * FROM kelas WHERE id_guru = '$_SESSION[idguru]'");
         $ketemu=mysql_num_rows($tampil_kelas);
         if (!empty($ketemu)){
                echo "<br><br><table id='table1' class='gtable sortable'><thead>
                <tr><th>No</th><th>Kelas</th><th>Wali Kelas</th><th>Ketua Kelas</th><th>Aksi</th></tr></thead>";

                $no=1;
                while ($r=mysql_fetch_array($tampil_kelas)){
                    echo "<tr><td>$no</td>
                    <td>$r[nama]</td>";
                    $kelas=$r[nama];
                    
                    $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$_SESSION[idguru]'");
                    $ada_guru = mysql_num_rows($guru);
                    if(!empty($ada_guru)){
                    while($p=mysql_fetch_array($guru)){
                            echo "<td>$p[nama_lengkap]</td>";
                    }
                    }else{
                            echo "<td></td>";
                    }

                    $siswa = mysql_query("SELECT * FROM siswa WHERE id_siswa = '$r[id_siswa]'");
                    $ada_siswa = mysql_num_rows($siswa);
                    if(!empty($ada_siswa)){
                    while ($s=mysql_fetch_array($siswa)){
                            echo"<td>$s[nama_lengkap]</td>";
                     }
                    }else{
                            echo"<td></td>";
                    }

                    echo "<td><input class='button small white' type=button value='Cetak Nilai Kelas $kelas' onclick=\"window.location.href='$aksi?module=laporansiswa&act=cetaklaporankelas&kelas=$kelas';\"></td>";
                $no++;
                }
                echo "</table>";
                }else{
                    echo "<script>window.alert('Tidak ada kelas yang anda ajar,kembali ke home untuk menambah');
                    window.location=(href='?module=home')</script>";
                }
    }
}
}
?>