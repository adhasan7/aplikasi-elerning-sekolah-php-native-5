<script>
function confirmdelete(delUrl) {
if (confirm("Anda yakin ingin menghapus?")) {
document.location = delUrl;
}
}
</script>
<script language="JavaScript" type="text/JavaScript">

 function showpel()
 {
 <?php

 // membaca semua kelas
 $query = "SELECT * FROM kelas";
 $hasil = mysql_query($query);

 // membuat if untuk masing-masing pilihan kelas beserta isi option untuk combobox kedua
 while ($data = mysql_fetch_array($hasil))
 {
   $idkelas = $data['id_kelas'];

   // membuat IF untuk masing-masing kelas
   echo "if (document.form_materi.id_kelas.value == \"".$idkelas."\")";
   echo "{";

   // membuat option matapelajaran untuk masing-masing kelas
   $query2 = "SELECT * FROM mata_pelajaran WHERE id_kelas = '$idkelas' AND id_guru = '0'";
   $hasil2 = mysql_query($query2);
   $content = "document.getElementById('pelajaran').innerHTML = \"<select name='".id_matapelajaran."'>";
   while ($data2 = mysql_fetch_array($hasil2))
   {
       $content .= "<option value='".$data2['id_matapelajaran']."'>".$data2['nama']."</option>";
   }
   $content .= "</select>\";";
   echo $content;
   echo "}\n";
 }

 ?>
 }
</script>

<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href=../css/style.css rel=stylesheet type=text/css>";
  echo "<div class='error msg'>Untuk mengakses Modul anda harus login.</div>";
}
else{

$aksi="modul/mod_matapelajaran/aksi_matapelajaran.php";
switch($_GET[act]){
// Tampil Mata Pelajaran
  default:
    if ($_SESSION[leveluser]=='admin'){
      $tampil_pelajaran = mysql_query("SELECT * FROM mata_pelajaran ORDER BY id_kelas");
      echo "<h2>Manajemen Mata Pelajaran</h2><hr>
          <input class='button blue' type=button value='Tambah mata pelajaran' onclick=\"window.location.href='?module=matapelajaran&act=tambahmatapelajaran';\">";
          echo "<br><br><table id='table1' class='gtable sortable'><thead>
          <tr><th>No</th><th>Id Mapel</th><th>Nama</th><th>Kelas</th><th>guru</th><th>Deskripsi</th><th>Aksi</th></tr></thead>";
    $no=1;
    while ($r=mysql_fetch_array($tampil_pelajaran)){
       echo "<tr><td>$no</td>
             <td>$r[id_matapelajaran]</td>
             <td>$r[nama]</td>";
             $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$r[id_kelas]'");
             $cek = mysql_num_rows($kelas);
             if(!empty($cek)){
             while($k=mysql_fetch_array($kelas)){
                 echo "<td><a href=?module=kelas&act=detailkelas&id=$r[id_kelas] title='Detail Kelas'>$k[nama]</td>";
             }
             }else{
                 echo"<td></td>";
             }
             $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$r[id_guru]'");
             $cek_guru = mysql_num_rows($guru);
             if(!empty($cek_guru)){
             while($p=mysql_fetch_array($guru)){
             echo "<td><a href=?module=admin&act=detailguru&id=$r[id_guru] title='Detail guru'>$p[nama_lengkap]</a></td>";
             }
             }else{
                 echo"<td></td>";
             }
             echo "<td>$r[deskripsi]</td>
             <td><a href='?module=matapelajaran&act=editmatapelajaran&id=$r[id]' title='Edit'><img src='images/icons/edit.png' alt='Edit' /></a> |
                 <a href=javascript:confirmdelete('$aksi?module=matapelajaran&act=hapus&id=$r[id]') title='Hapus'><img src='images/icons/cross.png' alt='Delete' /></a></td></tr>";
      $no++;
    }
    echo "</table>";
    }
    elseif ($_SESSION[leveluser]=='guru'){
     //mata pelajaran

  $tampil_pelajaran = mysql_query("SELECT * FROM mata_pelajaran WHERE id_guru = '$_SESSION[idguru]'");
  $cek_mapel = mysql_num_rows($tampil_pelajaran);
  if (!empty($cek_mapel)){
    echo"<h2>Mata Pelajaran Yang Anda Ajar</h2><hr>
    <input type=button class='button blue' value='Tambah' onclick=\"window.location.href='?module=matapelajaran&act=tambahmatapelajaran';\">";
    echo "<br><br><table id='table1' class='gtable sortable'><thead>
          <tr><th>No</th><th>Nama</th><th>Kelas</th><th>guru</th><th>Deskripsi</th><th>Aksi</th></tr></thead>";
    $no=1;
    while ($r=mysql_fetch_array($tampil_pelajaran)){
       echo "<tr><td>$no</td>             
             <td>$r[nama]</td>";
             $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$r[id_kelas]'");
             $cek = mysql_num_rows($kelas);
             if(!empty($cek)){
             while($k=mysql_fetch_array($kelas)){
                 echo "<td><a href=?module=kelas&act=detailkelas&id=$r[id_kelas] title='Detail Kelas'>$k[nama]</td>";
             }
             }else{
                 echo"<td></td>";
             }
             $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$r[id_guru]'");
             $cek_guru = mysql_num_rows($guru);
             if(!empty($cek_guru)){
             while($p=mysql_fetch_array($guru)){
             echo "<td><a href=?module=admin&act=detailguru&id=$r[id_guru] title='Detail guru'>$p[nama_lengkap]</a></td>";
             }
             }else{
                 echo"<td></td>";
             }
             echo "<td>$r[deskripsi]</td>
             <td><a href='?module=matapelajaran&act=editmatapelajaran&id=$r[id]' title='Edit'><img src='images/icons/edit.png' alt='Edit' /></a> |
                <a href=javascript:confirmdelete('$aksi_mapel?module=matapelajaran&act=hapus_mapel_guru&id=$r[id]') title='Hapus'><img src='images/icons/cross.png' alt='Delete' /></a>";
      $no++;
    }
    echo "</table>";
        }else{
            echo "<script>window.alert('Tidak ada mata pelajaran yang anda ajar, Kembali ke home untuk menambah mata pelajaran yang diajar');
            window.location=(href='?module=home')</script>";
        }
    }
    elseif ($_SESSION[leveluser]=='siswa'){
        $siswa = mysql_query("SELECT * FROM siswa WHERE id_siswa = $_SESSION[idsiswa]");
        $data_siswa = mysql_fetch_array($siswa);
        $tampil_pelajaran = mysql_query("SELECT * FROM absensi WHERE id_siswa = $_SESSION[idsiswa] ORDER BY tanggal DESC");
        echo"<br><b class='judul'>Daftar Absensi Anda</b><br><p class='garisbawah'></p>";
        echo "<table>
          <tr><th>No</th><th>IP Address</th><th>Login</th></tr>";
        $no=1;
        while ($r=mysql_fetch_array($tampil_pelajaran)){
        echo "<tr><td>$no</td>
             <td>$r[ip]</td>";             
             echo "<td>$r[tanggal]</td>";
        $no++;
        }
        echo "</table>";
    }
    break;

case "tambahmatapelajaran":
    if ($_SESSION[leveluser]=='admin'){
        echo "<form method=POST action='$aksi?module=matapelajaran&act=input_matapelajaran'>
          <fieldset>
          <legend>Tambah Mata Pelajaran</legend>
          <dl class='inline'>
          <dt><label>Id Matapelajaran</label></dt>     <dd>: <input type=text name='id_matapelajaran' size=10></dd>
          <dt><label>Nama</label></dt>                <dd>: <input type=text name='nama' size=30></dd>
          <dt><label>Kelas</label></dt>                <dd>: <select name='id_kelas'>
                                                  <option value=0 selected>--pilih--</option>";
                                                  $tampil=mysql_query("SELECT * FROM kelas ORDER BY nama");
                                                  while($r=mysql_fetch_array($tampil)){
                                                  echo "<option value=$r[id_kelas]>$r[nama]</option>";
                                                  }echo "</select></dd>
         <dt><label>guru</label></dt>              <dd>: <select name='id_guru'>
                                                  <option value=0 selected>--pilih--</option>";
                                                  $tampil_guru=mysql_query("SELECT * FROM guru ORDER BY nama_lengkap");
                                                  while($p=mysql_fetch_array($tampil_guru)){
                                                  echo "<option value=$p[id_guru]>$p[nama_lengkap]</option>";
                                                  }echo "</select></dd>
        <dt><label>Deskripsi</label></dt>             <dd>: <textarea name='deskripsi' id='wysiwyg' class='medium' rows='6'></textarea></td><tr>
          </dl>
          <div class='buttons'>
          <input class='button blue' type=submit value=Simpan>
          <input class='button blue' type=button value=Batal onclick=self.history.back()>
          </div>
          </fieldset></form>";
    }
    elseif ($_SESSION[leveluser]=='guru'){
        echo "<form method=POST name='form_materi' action='$aksi?module=matapelajaran&act=input_matapelajaran_guru'>          
          <fieldset>
          <legend>Mata Pelajaran Yang di Ajar</legend>
          <dl class='inline'>
          <dt><label>Kelas </label></dt>             <dd><select name='id_kelas' onChange='showpel()'>
                                          <option value=''>-pilih-</option>";
                                          $pilih="SELECT * FROM kelas ORDER BY id_kelas";
                                          $query=mysql_query($pilih);
                                          while($row=mysql_fetch_array($query)){
                                          echo"<option value='".$row[id_kelas]."'>".$row[nama]."</option>";
                                          }
                                          echo"</select></dd>
          <dt><label>Pelajaran </label></dt>          <dd><div id='pelajaran'><select name='id_matapelajaran'></select></div></dd>
          <dt><label>Deskripsi </label></dt>             <dd><textarea name='deskripsi' id='wysiwyg' class='medium' rows='6'></textarea></dd>
          <p align=center><input type=submit class='button blue' value=Simpan>
                      <input type=button class='button blue' value=Batal onclick=self.history.back()></p>
          </dl></fieldset></form>";
    }
    break;

case "editmatapelajaran":
    if ($_SESSION[leveluser]=='admin'){
        $mapel=mysql_query("SELECT * FROM mata_pelajaran WHERE id = '$_GET[id]'");
        $m=mysql_fetch_array($mapel);
        $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$m[id_kelas]'");
        $k = mysql_fetch_array($kelas);
        $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$m[id_guru]'");
        $d = mysql_fetch_array($guru);
        
        echo "
          <form method=POST action='$aksi?module=matapelajaran&act=update_matapelajaran'>
          <input type=hidden name=id value='$m[id]'>
          <fieldset>
          <legend>Edit Mata Pelajaran</legend>
          <dl class='inline'>
          <dt><label>Id Matapelajaran</label></dt>     <dd>: <input type=text name='id_matapelajaran' size=10 value='$m[id_matapelajaran]'></dd>
          <dt><label>Nama</label></dt>                 <dd>: <input type=text name='nama' size=30 value='$m[nama]'></dd>
          <dt><label>Kelas</label></dt>                <dd>: <select name='id_kelas'>
                                                  <option value='$k[id_kelas]' selected>$k[nama]</option>";
                                                  $tampil=mysql_query("SELECT * FROM kelas ORDER BY nama");
                                                  while($r=mysql_fetch_array($tampil)){
                                                  echo "<option value=$r[id_kelas]>$r[nama]</option>";
                                                  }echo "</select></dd>
         <dt><label>guru</label></dt>              <dd>: <select name='id_guru'>
                                                  <option value='$d[id_guru]' selected>$d[nama_lengkap]</option>";
                                                  $tampil_guru=mysql_query("SELECT * FROM guru ORDER BY nama_lengkap");
                                                  while($p=mysql_fetch_array($tampil_guru)){
                                                  echo "<option value=$p[id_guru]>$p[nama_lengkap]</option>";
                                                  }echo "</select></dd>
        <dt><label>Deskripsi</label></dt>            <dd>: <textarea name='deskripsi' id='wysiwyg' class='medium' rows='6'>$m[deskripsi]</textarea></dd>
        </dl>
          <div class='buttons'>
          <input class='button blue' type=submit value=Update>
          <input class='button blue' type=button value=Batal onclick=self.history.back()>
          </div>
          </fieldset></form>";
    }else{
        $mapel=mysql_query("SELECT * FROM mata_pelajaran WHERE id = '$_GET[id]'");
        $m=mysql_fetch_array($mapel);
        $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$m[id_kelas]'");
        $k = mysql_fetch_array($kelas);
        $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$m[id_guru]'");
        $d = mysql_fetch_array($guru);

        echo "<form method=POST name='form_materi' action='$aksi?module=matapelajaran&act=update_matapelajaran_guru'>
          <input type=hidden name=id value='$m[id]'>
          <fieldset>
          <legend>Edit Mata Pelajaran</legend>
          <dl class='inline'>
          <dt><label>Kelas </label></dt>             <dd><select name='id_kelas' onChange='showpel()'>
                                          <option value='$k[id_kelas]' selected>$k[nama]</option>";
                                          $pilih="SELECT * FROM kelas ORDER BY nama";
                                          $query=mysql_query($pilih);
                                          while($row=mysql_fetch_array($query)){
                                          echo"<option value='".$row[id_kelas]."'>".$row[nama]."</option>";
                                          }
                                          echo"</select></dd>
          <dt><label>Pelajaran </label></dt>         <dd><select id='pelajaran' name='id_matapelajaran'>
                                          <option value='".$m[id_matapelajaran]."' selected>".$m[nama]."</option>
                                          </select></dd>
          <dt><label>Deskripsi </label></dt>         <dd><textarea name='deskripsi' id='wysiwyg' class='medium' rows='6'>$m[deskripsi]</textarea></dd>
          <p align=center><input class='button blue' type=submit value=Simpan>
                      <input class='button blue' type=button value=Batal onclick=self.history.back()></p>
          </dl></fieldset></form>";
    }
    break;
case "detailpelajaran":
    if ($_SESSION[leveluser]=='admin'){
        $detail =mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$_GET[id]'");
        echo "<div class='information msg'>Detail Mata Pelajaran</div>
          <br><table id='table1' class='gtable sortable'><thead>
          <tr><th>No</th><th>Id Mapel</th><th>Nama</th><th>Kelas</th><th>guru</th><th>Deskripsi</th><th>Aksi</th></tr></thead>";
        $no=1;
    while ($r=mysql_fetch_array($detail)){
       echo "<tr><td>$no</td>
             <td>$r[id_matapelajaran]</td>
             <td>$r[nama]</td>";
             $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$r[id_kelas]'");
             $cek_kelas = mysql_num_rows($kelas);
             if(!empty($cek_kelas)){
             while($k=mysql_fetch_array($kelas)){
                 echo "<td><a href=?module=kelas&act=detailkelas&id=$r[id_kelas] title='Detail Kelas'>$k[nama]</td>";
             }
             }else{
                 echo"<td></td>";
             }
             $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$r[id_guru]'");
             $cek_guru = mysql_num_rows($guru);
             if(!empty($cek_guru)){
             while($p=mysql_fetch_array($guru)){
             echo "<td><a href=?module=admin&act=detailguru&id=$r[id_guru] title='Detail guru'>$p[nama_lengkap]</a></td>";
             }
             }else{
                 echo"<td></td>";
             }
             echo "<td>$r[deskripsi]</td>
             <td><a href='?module=matapelajaran&act=editmatapelajaran&id=$r[id]' title='Edit'><img src='images/icons/edit.png' alt='Edit' /></a> |
                 <a href=javascript:confirmdelete('$aksi?module=matapelajaran&act=hapus&id=$r[id]') title='Hapus'><img src='images/icons/cross.png' alt='Delete' /></a></td></tr>";
      $no++;
    }
    echo "</table>
    <div class='buttons'>
    <br><input class='button blue' type=button value=Kembali onclick=self.history.back()>
    </div>";
    }else{
      $detail =mysql_query("SELECT * FROM mata_pelajaran WHERE id_matapelajaran = '$_GET[id]'");
        echo "<span class='judulhead'><p class='garisbawah'>Detail Mata Pelajaran</p></span>
          <table>
          <tr><th>no</th><th>nama</th><th>kelas</th><th>guru</th><th>deskripsi</th></tr>";
                    $no=1;
    while ($r=mysql_fetch_array($detail)){
       echo "<tr><td>$no</td>             
             <td>$r[nama]</td>";
             $kelas = mysql_query("SELECT * FROM kelas WHERE id_kelas = '$r[id_kelas]'");
             $cek_kelas = mysql_num_rows($kelas);
             if(!empty($cek_kelas)){
             while($k=mysql_fetch_array($kelas)){
                 echo "<td><a href=?module=kelas&act=detailkelas&id=$r[id_kelas] title='Detail Kelas'>$k[nama]</td>";
             }
             }else{
                 echo"<td></td>";
             }
             $guru = mysql_query("SELECT * FROM guru WHERE id_guru = '$r[id_guru]'");
             $cek_guru = mysql_num_rows($guru);
             if(!empty($cek_guru)){
             while($p=mysql_fetch_array($guru)){
             echo "<td><a href=?module=admin&act=detailguru&id=$r[id_guru] title='Detail guru'>$p[nama_lengkap]</a></td>";
             }
             }else{
                 echo"<td></td>";
             }
             echo "<td>$r[deskripsi]</td></tr>";
             
      $no++;
    }
    echo "</table>
    <input type=button value=Kembali onclick=self.history.back()>";
    }
    break;
}
}
?>