<?php
header ('location:media.php?home');
?>