<?php

echo "<li><a href='media.php?module=kelas'><b>Kelas Anda</b></a></li>";
echo "<li><a href='media.php?module=matapelajaran'><b>Mata Pelajaran</b></a></li>";
echo "<li><a href='media.php?module=materi'><b>Materi</b></a></li>";
echo "<li><a href='media.php?module=quiz'><b>Tugas / Quiz</b></a></li>";
echo "<li><a href='media.php?module=nilai'><b>Nilai</b></a></li>";
echo "<li><a href='media.php?module=absensi'><b>Absensi</b></a></li>";
echo "<li><a href='media.php?module=video'><b>Video Tutorial</b></a></li>";
?>