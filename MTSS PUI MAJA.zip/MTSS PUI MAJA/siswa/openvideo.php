<?php
include "../configurasi/koneksi.php";

$id = $_GET['id'];
$linkvideo = $_GET['linkvideo'];
$ctype="youtube";

if ($linkvideo==""){
  echo "<h1>Access forbidden!</h1>
        <p>Maaf, link video yang Anda buka sudah tidak tersedia atau video telah dihapus. <br />
        Silahkan hubungi <a href='mailto:admin@elearning.mtsspuimaja.sch.id'>webmaster</a>.</p>";
  exit;
}
else{
  mysql_query("update video set hits=hits+1 where id_video='$id'");
  header('location:'.$linkvideo);  
}

function open_window($url){
echo "<script type='text/javascript'>
        window.open ('" . $url . "', '_blank');
    </script>";
}   
?>