SEBELUM MENJALANKAN WEB ELEARNING INI ADA BEBERAPA KONFIGURASI YANG HARUS DILAKUKAN
------------------------------------------------------------------------------------

1. Buat database baru dengan nama mtsspuimaja

2. Import database yang saya sertakan pada folder database

3. Buka file koneksi.php yang ada pada folder configurasi

4. Sesuaikan user dan password mysql anda, serta nama database yang anda buat

5. LOGIN SEBAGAI ADMINISTRATOR
   -------------------------------------

	localhost/folder program/administrator
	
	ACCOUNT :
	--------
	
	1. username : admin, password: admin

   LOGIN SEBAGAI PENGAJAR
   --------------------------------

	localhost/folder program/administrator
	
	ACCOUNT : 
	----------

	1. username : amiruddin, password: amiruddin

	2. username : rina, password: rina

   LOGIN SEBAGAIN SISWA
   -------------------------

	localhost/folder program

	ACCOUNT :
	----------

	1. username : hasan, password: hasan

	2. username : hilman, password: hilman
