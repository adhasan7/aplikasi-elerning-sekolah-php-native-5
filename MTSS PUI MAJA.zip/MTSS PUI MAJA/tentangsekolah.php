<div id="content">

   <div id="contentleft">

      <div class="postarea">

        <h1 align="justify"><img src='images/logo.png' width='25' height='25'></img>&nbsp;&nbsp;&nbsp;Profil Sekolah</h1><br />

         <div class="skn-cont-frame">
  <!-- data header -->
  <div class="skn-data-head" id="rekap">
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <!-- title -->
          <td class="title-frm"><div class="sec-title">&nbsp;</div>
            <div class="data-frm">
              <div class="icon gedung"></div>
              <div class="icon-sml grafik-sml"></div>
              <div class="title">Rekapitulasi Sekolah</div>
              <table cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td><strong>MTSS PUI MAJA<br>
                      </strong></td>
                  </tr>
                </tbody>
              </table>
            </div></td>
        </tr>
      </tbody>
    </table>
    <!-- separator -->
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <td class="sep"><div class="point"></div></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div id="siap_view">
    <!-- data -->
    <div class="skn-data">
      <div class="tbl-act">
        <div class="skn-clr"></div>
      </div>
      <div class="tbl-act">
      <!-- table data -->
      <div class="summary">
        <div style="float: left;">
          <div class="item">
            <div class="icon siswa"></div>
            <div class="icon-sml daftar-sml"></div>
            <span><span class="big">2032</span> <span class="medium">siswa</span></span><br>
          </div>
        </div>
        <div style="float: left;">
          <div class="item">
            <div class="icon guru"></div>
            <div class="icon-sml daftar-sml"></div>
            <span><span class="big">27</span> <span class="medium">guru</span></span><br>
          </div>
        </div>
        <div style="float: left;">
          <div class="item">
            <div class="icon pelajaran"></div>
            <div class="icon-sml daftar-sml"></div>
            <span><span class="big">1</span> <span class="medium">jurusan</span></span><br>
          </div>
        </div>
        <div style="float: left;">
          <div class="item">
            <div class="icon kelas"></div>
            <div class="icon-sml daftar-sml"></div>
            <span><span class="big">13</span> <span class="medium">kelas</span></span><br>
          </div>
        </div>
        <div style="float: left;">
          <div class="item">
            <div class="icon pelajaran"></div>
            <div class="icon-sml daftar-sml"></div>
            <span><span class="big">123</span> <span class="medium">pelajaran</span></span><br>
          </div>
        </div>
        <div style="float: left;">
          <div style="width: 147px;" class="item">
            <div class="icon ekstrakuri"></div>
            <div class="icon-sml daftar-sml"></div>
            <span><span class="big">7</span> <span class="medium">ekstrakurikuler</span></span><br>
          </div>
        </div>
        <div style="clear: both;"></div>
      </div>
      <!-- table data -->
      </div>
      <!-- table action -->
    </div>
    <!-- data footer -->
	<!-- data footer -->
<div class="skn-data-foot">
  <div class="sumber">sumber: database SIAP Administrasi 2.0</div>
</div>
        <div class="skn-clr"></div>
  </div>
  <div id="siap_edit"></div>
  <div class="skn-clr"></div>
</div>

<div class="skn-cont-frame" id="infosekolah">
  <!-- data header -->
  <div class="skn-data-head">
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <!-- logo -->
          <td class="logo-frm"><img height="54" width="54" id="data-foto-detail" src="http://s.sim.siap-online.com//upload/sekolah/20214064.190926095214.jpg"></td>
          <!-- title -->
          <td class="title-frm"><div class="sec-title"></div>
            <div class="data-frm">
              <div class="icon gedung"></div>
              <div class="icon-sml info-sml"></div>
              <div class="title">Info Sekolah</div>
              <table cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td><strong>MTSS PUI MAJA<br>
                      </strong></td>
                  </tr>
                </tbody>
              </table>
            </div></td>
        </tr>
      </tbody>
    </table>
    <!-- separator -->
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <td class="sep"><div class="point"></div></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div id="siap_view">
    <!-- data -->
    <div class="skn-data">
      <!-- table action -->
      <div class="tbl-act">
      </div>
      <!-- table data -->
      <table cellspacing="0" cellpadding="0" border="0" class="data-tbl-strecth" id="sortme">
      <tbody>
                  <tr>
            <td class="title">NPSN</td>
            <td>20278920&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">NSS</td>
            <td>121232100011&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Nama</td>
            <td>MTSS PUI MAJA&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Akreditasi</td>
            <td>Akreditasi A&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Alamat</td>
            <td>Jl. KH. Abdul  Halim No.01 Maja Selatan&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Kodepos</td>
            <td>45461&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Nomer Telpon</td>
            <td>085222051898&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Nomer Faks</td>
            <td>-&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Surel</td>
            <td>mtspuimaja@yahoo.com&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Jenjang</td>
            <td>SMP&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Status</td>
            <td>Swasta&nbsp;</td>
         </tr>
         		         <tr>
		            <td class="title">Situs</td>
		            <td>http://mtspuimaja.sch.id, mtspuimaja.majalengkakab.sch.id&nbsp;</td>
		         </tr>
					
				         <tr>
            <td class="title">Lintang</td>
            <td>-6.889943095188971&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Bujur</td>
            <td>108.30187886953354&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Ketinggian</td>
            <td>586&nbsp;</td>
         </tr>
                  <tr>
            <td class="title">Waktu Belajar</td>
            <td>Sekolah Pagi&nbsp;</td>
         </tr>
                 </tbody>
   </table>
       </div>
    <!-- data footer -->
	    <div class="skn-clr"></div>
  </div>
  <div id="siap_edit"></div>
  <div class="skn-clr"></div>
</div>


<div class="skn-cont-frame" id="infosekolah">
  <!-- data header -->
  <div class="skn-data-head">
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <!-- logo -->
          <td class="logo-frm"><img height="54" width="54" id="data-foto-detail" src="http://s.sim.siap-online.com//upload/sekolah/20214064.190926095214.jpg"></td>
          <!-- title -->
          <td class="title-frm"><div class="sec-title"></div>
            <div class="data-frm">
              <div class="icon gedung"></div>
              <div class="icon-sml lokasi-sml"></div>
              <div class="title">Lokasi Sekolah</div>
              <table cellspacing="0" cellpadding="0" border="0">
                <tbody>
                  <tr>
                    <td><strong>MTSS PUI MAJA<br>
                      </strong></td>
                  </tr>
                </tbody>
              </table>
            </div></td>
        </tr>
      </tbody>
    </table>
    <!-- separator -->
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <td class="sep"><div class="point"></div></td>
        </tr>
      </tbody>
    </table>
  </div>
  <div id="siap_view">
    <!-- data -->
    <div class="skn-data">
      <!-- table action -->
      <div class="tbl-act">
      </div>
      <!-- table data -->

      <table cellspacing="0" cellpadding="0" border="0" class="data-tbl-strecth" id="sortme">
            <tr>
         <td class="title">Kota</td>
         <td>Kab. Majalengka&nbsp;</td>
      </tr>
            <tr>
         <td class="title">Propinsi</td>
         <td>Jawa Barat&nbsp;</td>
      </tr>
            <tr>
         <td class="title">Kecamatan</td>
         <td>Maja&nbsp;</td>
      </tr>
            <tr>
         <td class="title">Kelurahan</td>
         <td>Maja Selatan&nbsp;</td>
      </tr>
            <tr>
         <td class="title">Kodepos</td>
         <td>45461&nbsp;</td>
      </tr>
         </table>
            <!-- table action -->
    </div>
    <!-- data footer -->
	    <div class="skn-clr"></div>
  </div>
  <div id="siap_edit"></div>
  <div class="skn-clr"></div>
</div>