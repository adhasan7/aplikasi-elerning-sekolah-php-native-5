<?php
include "configurasi/koneksi.php";
function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['user']);
$pass     = anti_injection($_POST['password']);
$pass=md5($_POST['password']);
$pass_user     = anti_injection($_POST['password']);

$level=$_POST['level'];
if($level=='admin'){
$login=mysql_query("SELECT * FROM admin WHERE username='$username' AND password='$pass' AND blokir='N'");
$ketemu=mysql_num_rows($login);
$r=mysql_fetch_array($login);
// Apabila username dan password ditemukan
if ($ketemu > 0){
  session_start();
  include "timeout.php";  
  $_SESSION[idadmin]      = $r[id_admin];
  $_SESSION[namauser]     = $r[username];
  $_SESSION[namalengkap]  = $r[nama_lengkap];
  $_SESSION[passuser]     = $r[password];
  $_SESSION[leveluser]    = $level;
  $_SESSION[email]		  = $r[email];  
  $_SESSION[login] = 1;  
  timer();
  
  $sid_lama = session_id();
  session_regenerate_id();
  $sid_baru = session_id();
  mysql_query("UPDATE admin SET id_session='$sid_baru' WHERE username='$username'");
  header('location:administrator/media_admin.php?module=home');
}
else{
  echo "<script>alert('Maaf, Password Dan Username Anda Tidak Benar, atau account anda sudah di blokir !');javascript:history.go(-1) </script>";
}
}elseif($level=='guru'){
$login=mysql_query("SELECT * FROM guru WHERE username_login='$username' AND password_login='$pass' AND blokir='N'");
$ketemu=mysql_num_rows($login);
$r=mysql_fetch_array($login);
// Apabila username dan password ditemukan
if ($ketemu > 0){
  session_start();
  include "timeout.php";
  $_SESSION[nip]          = $r[nip];
  $_SESSION[idguru]   = $r[id_guru];
  $_SESSION[namauser]     = $r[username_login];
  $_SESSION[namalengkap]  = $r[nama_lengkap];
  $_SESSION[passuser]     = $r[password_login];
  $_SESSION[leveluser]    = $level;
  $_SESSION[email]		  = $r[email];
  $_SESSION[login] = 1;  
  timer();
  
  $sid_lama = session_id();
  session_regenerate_id();
  $sid_baru = session_id();
  mysql_query("UPDATE guru SET id_session='$sid_baru' WHERE username_login='$username'");
  header('location:administrator/media_admin.php?module=home');
}
else{
  $sql= "SELECT * FROM admin WHERE username='$username' AND password='$pass' AND blokir='N'";
  //echo "<script>alert($sql) </script>";
  echo "<script>alert('Maaf, Password Dan Username Anda Tidak Benar, atau account anda sudah di blokir !');javascript:history.go(-1) </script>";
}
}else{
$login=mysql_query("SELECT * FROM siswa WHERE username_login='$username' AND password_login='$pass' AND blokir='N'");
$ketemu=mysql_num_rows($login);
$r=mysql_fetch_array($login);
// Apabila username dan password ditemukan
if ($ketemu > 0){
  session_start();
  include "timeout.php";
  $_SESSION[namauser]     = $r[username_login];
  $_SESSION[namalengkap]  = $r[nama_lengkap];
  $_SESSION[passuser]     = $r[password_login];
  $_SESSION[leveluser]    = $r[level];
  $_SESSION[idsiswa]      = $r[id_siswa];

  // session timeout
  $_SESSION[login] = 1;
  timer();
  
  $sid_lama = session_id();
  session_regenerate_id();
  $sid_baru = session_id();
  $waktu = date("H:i:s");
  $tgl = date("Y-m-d");

  mysql_query("UPDATE siswa SET id_session='$sid_baru' WHERE username_login='$username'");
  

    $ip      = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP komputer user
    $tanggal = date("Y-m-d H:i:s"); // Mendapatkan tanggal sekarang
    $waktu   = time("U"); //

  $user = mysql_query("SELECT * FROM online WHERE id_siswa='$_SESSION[idsiswa]'");
  if (mysql_num_rows($user)== 0){
      mysql_query("INSERT INTO online (ip,id_siswa,tanggal,online)
                               VALUES ('$ip','$_SESSION[idsiswa]','$tanggal','Y')");
  }
  else{
     $ip      = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP komputer user
     $tanggal = date("Y-m-d H:i:s"); // Mendapatkan tanggal sekarang
     $waktu   = time("U"); //
     mysql_query("UPDATE online SET ip='$ip',tanggal='$tanggal',online='Y' WHERE id_siswa = '$_SESSION[idsiswa]'");
  }

      mysql_query("INSERT INTO absensi (ip,id_siswa,tanggal,online)
                               VALUES ('$ip','$_SESSION[idsiswa]','$tanggal','Y')");
  
  header('location:./siswa/media.php?module=home');
}
else{
  echo "<script>alert('Maaf, Password Dan Username Anda Tidak Benar, atau account anda sudah di blokir !');javascript:history.go(-1) </script>";
}
}

?>